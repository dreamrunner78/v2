from airflow import DAG
from datetime import datetime, timedelta
from airflow.contrib.operators.kubernetes_pod_operator import KubernetesPodOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from kubernetes.client import models as k8s
from airflow.utils.task_group import TaskGroup


# START HEADER

compute_resources_1bwixog=k8s.V1ResourceRequirements(
    requests={
        'cpu': '1',
        'memory': '1G'
    },
    limits={
        'cpu': '1',
        'memory': '1G'
    }
)


#TMP DIRECTORY
volume_mount_tmpdir_1bwixog = k8s.V1VolumeMount(
  mount_path="/tmp", 
  name="tmp", 
  sub_path=None, 
  read_only=False
)
volume_tmpdir_1bwixog = k8s.V1Volume(
    name="tmp",
    empty_dir=k8s.V1EmptyDirVolumeSource()
)

#MOUNT SECRET STORE
volume_mount_secret_1bwixog_sqlsecret = k8s.V1VolumeMount(
  mount_path="/opt/dcp/secrets/sqlsecret", 
  name="1bwixogsqlsecret", 
)
volume_secret_1bwixog = k8s.V1Volume(
    name="1bwixogsqlsecret", 
    secret=k8s.V1SecretVolumeSource(secret_name="sqlsecret")
)


#SCRIPT
python_script_1bwixog = """
#Python script
#Python script
import sys
import trino

if not sys.warnoptions:
        import warnings
warnings.simplefilter("ignore")

def get_connection():
    connection = trino.dbapi.connect(
        host="sql-asxkl-sql-asxklcpheaj-svc.demo.svc.cluster.local",
        port=8443,
        user="sqltechuser",
        http_scheme='https',
        auth=trino.auth.BasicAuthentication("sqltechuser", open("/trino-users/dcpadminusername").read()),
        #auth=trino.auth.BasicAuthentication("sqltechuser", "Password2016."),
    )
    connection._http_session.verify = False
    return connection
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()

connection = get_connection()
run_query(connection, \"""
    create table if not exists lakehouse.taxi.yellow_tripdata with (
        location = 's3a://lakehouse/taxi/',
        partitioning = ARRAY['month(tpep_pickup_datetime)']
    )
    as select
        VendorID as vendor_id,
        cast(tpep_pickup_datetime as timestamp(6)) as tpep_pickup_datetime,
        cast(tpep_dropoff_datetime as timestamp(6)) as tpep_dropoff_datetime,
        cast(passenger_count as BIGINT) as passenger_count,
        trip_distance,
        r.rate_code,
        store_and_fwd_flag,
        z_pickup.borough as pickup_borough,
        z_pickup.zone as pickup_zone,
        z_pickup.service_zone as pickup_service_zone,
        z_dropoff.borough as dropoff_borough,
        z_dropoff.zone as dropoff_zone,
        z_dropoff.service_zone as dropoff_service_zone,
        p.payment_type as payment_type,
        fare_amount,
        extra,
        mta_tax,
        tip_amount,
        tolls_amount,
        improvement_surcharge,
        total_amount,
        congestion_surcharge,
        airport_fee
    from staging.taxi.yellow_tripdata as t
    left join staging.taxi.taxi_zone_lookup as z_pickup on t.pulocationid = cast(z_pickup.location_id as bigint)
    left join staging.taxi.taxi_zone_lookup as z_dropoff on t.dolocationid = cast(z_dropoff.location_id as bigint)
    left join staging.taxi.payment_type_lookup as p on t.payment_type = cast(p.payment_type_id as bigint)
    left join staging.taxi.rate_code_lookup as r on t.ratecodeid = cast(r.rate_code_id as bigint)
    where tpep_pickup_datetime >= date '2015-01-01' and tpep_pickup_datetime <= now()
\""")

connection.close()
"""
# END HEADER

default_args = {
    'owner': 'dcp',
    'depends_on_past': True,    
    'start_date': datetime(2023, 1, 1),
    'retries': 1,
    'retry_delay': timedelta(minutes=10),
}

# Python JOB



with DAG(
    dag_id='pythonjob_lakehousea', 
    default_args=default_args,
    schedule_interval=None,
    max_active_runs=1,
    catchup=False) as dag:

# START TASK
    with TaskGroup("lakehousea", tooltip="Tasks for section_1") as lakehousea:
        previous_task= DummyOperator(task_id='lakehousea_group_start_wnmonc')
        
        ############################# stepa #############################
        python_task_1bwixog = KubernetesPodOperator(
        namespace='demo',
        image="docker.io/dcptechnologies/airflow:python-3.9.19-pgs-trino",
        image_pull_secrets=[k8s.V1LocalObjectReference("dcpregistry")],
        cmds=[
        "python", 
        "-c", 
        python_script_1bwixog
        ],
        name="run-python-script_1bwixog",
        task_id=f'1bwixog_1',
        schedulername='default-scheduler',
        volume_mounts=[volume_mount_tmpdir_1bwixog,volume_mount_secret_1bwixog_sqlsecret],
        volumes=[volume_tmpdir_1bwixog,volume_secret_1bwixog],
        security_context={
        "runAsNonRoot": True,
        "runAsUser": 1001010000,
        "allowPrivilegeEscalation": False,
        "seccompProfile":{
            "type": "RuntimeDefault"
        },
        "capabilities": {
            'drop': '["ALL"]'
        }
        },
        container_resources=compute_resources_1bwixog,
        get_logs=True,
        dag=dag,
        )
        # Set dependencies to ensure sequential execution
        previous_task >> python_task_1bwixog
        previous_task = python_task_1bwixog
        
    lakehousea_start= DummyOperator(task_id='lakehousea_start', dag=dag)
    lakehousea_end= DummyOperator(task_id='lakehousea_end', dag=dag)
# END TASK

# START EDGE
    lakehousea_start.set_downstream(lakehousea)
    lakehousea.set_downstream(lakehousea_end)
# END EDGE