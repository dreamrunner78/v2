#Python script
#Python script
import sys
import trino

if not sys.warnoptions:
        import warnings
warnings.simplefilter("ignore")

def get_connection():
    connection = trino.dbapi.connect(
        host="sql-asxkl-sql-asxklcpheaj-svc.demo.svc.cluster.local",
        port=8443,
        user="sqltechuser",
        http_scheme='https',
        auth=trino.auth.BasicAuthentication("sqltechuser", open("/opt/dcp/secrets/sqlsecret/password").read()),
        #auth=trino.auth.BasicAuthentication("sqltechuser", "Password2016."),
    )
    connection._http_session.verify = False
    return connection
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()

connection = get_connection()
run_query(connection, \"""
    create table if not exists lakehouse.taxi.yellow_tripdata with (
        location = 's3a://lakehouse/taxi/',
        partitioning = ARRAY['month(tpep_pickup_datetime)']
    )
    as select
        VendorID as vendor_id,
        cast(tpep_pickup_datetime as timestamp(6)) as tpep_pickup_datetime,
        cast(tpep_dropoff_datetime as timestamp(6)) as tpep_dropoff_datetime,
        cast(passenger_count as BIGINT) as passenger_count,
        trip_distance,
        r.rate_code,
        store_and_fwd_flag,
        z_pickup.borough as pickup_borough,
        z_pickup.zone as pickup_zone,
        z_pickup.service_zone as pickup_service_zone,
        z_dropoff.borough as dropoff_borough,
        z_dropoff.zone as dropoff_zone,
        z_dropoff.service_zone as dropoff_service_zone,
        p.payment_type as payment_type,
        fare_amount,
        extra,
        mta_tax,
        tip_amount,
        tolls_amount,
        improvement_surcharge,
        total_amount,
        congestion_surcharge,
        airport_fee
    from staging.taxi.yellow_tripdata as t
    left join staging.taxi.taxi_zone_lookup as z_pickup on t.pulocationid = cast(z_pickup.location_id as bigint)
    left join staging.taxi.taxi_zone_lookup as z_dropoff on t.dolocationid = cast(z_dropoff.location_id as bigint)
    left join staging.taxi.payment_type_lookup as p on t.payment_type = cast(p.payment_type_id as bigint)
    left join staging.taxi.rate_code_lookup as r on t.ratecodeid = cast(r.rate_code_id as bigint)
    where tpep_pickup_datetime >= date '2015-01-01' and tpep_pickup_datetime <= now()
\""")

connection.close()