#Python script
#Python script
import sys
import trino

if not sys.warnoptions:
        import warnings
warnings.simplefilter("ignore")

def get_connection():
    connection = trino.dbapi.connect(
        host="sql-asxkl-sql-asxklcpheaj-svc.demo.svc.cluster.local",
        port=8443,
        user="sqltechuser",
        http_scheme='https',
        auth=trino.auth.BasicAuthentication("sqltechuser", open("/opt/dcp/secrets/sqlsecret/password").read()),
        #auth=trino.auth.BasicAuthentication("sqltechuser", "Password2016."),
    )
    connection._http_session.verify = False
    return connection
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()

connection = get_connection()
run_query(connection, \"""
    create or replace materialized view lakehouse.taxi.yellow_tripdata_daily_agg as
    select
        date_trunc('day', tpep_pickup_datetime) as day,
        pickup_borough,
        pickup_zone,
        dropoff_borough,
        dropoff_zone,
        payment_type,
        count(*) as trips,
        avg(total_amount) as avg_total_amount,
        sum(total_amount) as sum_total_amount,
        avg(airport_fee) as avg_airport_fee,
        sum(airport_fee) as sum_airport_fee,
        avg(trip_distance) as avg_trip_distance,
        sum(trip_distance) as sum_trip_distance
    from lakehouse.taxi.yellow_tripdata
    group by 1, 2, 3, 4, 5, 6;
\""")

connection.close()