#Python script
#Python script
import sys
import trino

if not sys.warnoptions:
        import warnings
warnings.simplefilter("ignore")

def get_connection():
    connection = trino.dbapi.connect(
        host="sql-asxkl-sql-asxklcpheaj-svc.demo.svc.cluster.local",
        port=8443,
        user="sqltechuser",
        http_scheme='https',
        auth=trino.auth.BasicAuthentication("sqltechuser", open("/opt/dcp/secrets/sqlsecret/password").read()),
        #auth=trino.auth.BasicAuthentication("sqltechuser", "Password2016."),
    )
    connection._http_session.verify = False
    return connection
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()
    
def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()

# Liste des requêtes à exécuter
queries = [
    "REFRESH MATERIALIZED VIEW lakehouse.taxi.yellow_tripdata_daily_agg",
    "REFRESH MATERIALIZED VIEW lakehouse.taxi.yellow_tripdata_monthly_agg",
    # Ajoutez d'autres requêtes si nécessaire
]

connection = get_connection()

for query in queries:
    run_query(connection, query)

connection.close()