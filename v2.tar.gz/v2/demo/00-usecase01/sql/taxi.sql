drop schema if exists staging.house_sales cascade;
drop schema if exists staging.earthquakes cascade;
drop schema if exists staging.smart_city cascade;
drop schema if exists staging.taxi cascade;

drop schema if exists lakehouse.house_sales cascade;
drop schema if exists lakehouse.earthquakes cascade;
drop schema if exists lakehouse.smart_city cascade;
drop schema if exists lakehouse.taxi cascade;

CREATE SCHEMA IF NOT EXISTS staging.house_sales WITH (location = 's3a://staging/house-sales/');
CREATE SCHEMA IF NOT EXISTS staging.earthquakes WITH (location = 's3a://staging/earthquakes/');
CREATE SCHEMA IF NOT EXISTS staging.smart_city WITH (location = 's3a://staging/smart-city/');
CREATE SCHEMA IF NOT EXISTS staging.taxi WITH (location = 's3a://staging/taxi/');

CREATE SCHEMA IF NOT EXISTS lakehouse.house_sales WITH (location = 's3a://lakehouse/house-sales/');
CREATE SCHEMA IF NOT EXISTS lakehouse.earthquakes WITH (location = 's3a://lakehouse/earthquakes/');
CREATE SCHEMA IF NOT EXISTS lakehouse.smart_city WITH (location = 's3a://lakehouse/smart-city/');
CREATE SCHEMA IF NOT EXISTS lakehouse.taxi WITH (location = 's3a://lakehouse/taxi/');

CREATE TABLE IF NOT EXISTS staging.taxi.taxi_zone_lookup (
    location_id VARCHAR,
    borough VARCHAR,
    zone VARCHAR,
    service_zone VARCHAR
) WITH (
    external_location = 's3a://staging/taxi/taxi-zone-lookup/',
    format = 'csv',
    csv_escape = '\',
    csv_quote = '"',
    csv_separator = ',',
    skip_header_line_count = 1
);

CREATE TABLE IF NOT EXISTS staging.taxi.payment_type_lookup (
    payment_type_id VARCHAR,
    payment_type VARCHAR
) WITH (
    external_location = 's3a://staging/taxi/payment-type-lookup/',
    format = 'csv',
    csv_escape = '\',
    csv_quote = '"',
    csv_separator = ',',
    skip_header_line_count = 1
);

CREATE TABLE IF NOT EXISTS staging.taxi.rate_code_lookup (
    rate_code_id VARCHAR,
    rate_code VARCHAR
) WITH (
    external_location = 's3a://staging/taxi/rate-code-lookup/',
    format = 'csv',
    csv_escape = '\',
    csv_quote = '"',
    csv_separator = ',',
    skip_header_line_count = 1
);

CREATE TABLE IF NOT EXISTS staging.taxi.yellow_tripdata (
    VendorID BIGINT,
    tpep_pickup_datetime TIMESTAMP,
    tpep_dropoff_datetime TIMESTAMP,
    passenger_count DOUBLE,
    trip_distance DOUBLE,
    RatecodeID DOUBLE,
    store_and_fwd_flag VARCHAR,
    PULocationID BIGINT,
    DOLocationID BIGINT,
    payment_type BIGINT,
    fare_amount DOUBLE,
    extra DOUBLE,
    mta_tax DOUBLE,
    tip_amount DOUBLE,
    tolls_amount DOUBLE,
    improvement_surcharge DOUBLE,
    total_amount DOUBLE,
    congestion_surcharge DOUBLE,
    airport_fee DOUBLE
) WITH (
    external_location = 's3a://staging/taxi/yellow-tripdata/',
    format = 'parquet'
);

analyze staging.taxi.payment_type_lookup;

analyze staging.taxi.rate_code_lookup;

analyze staging.taxi.taxi_zone_lookup;

create table if not exists lakehouse.taxi.yellow_tripdata with (
    location = 's3a://lakehouse/taxi/',
    partitioning = ARRAY['month(tpep_pickup_datetime)']
)
as select
    VendorID as vendor_id,
    cast(tpep_pickup_datetime as timestamp(6)) as tpep_pickup_datetime,
    cast(tpep_dropoff_datetime as timestamp(6)) as tpep_dropoff_datetime,
    cast(passenger_count as BIGINT) as passenger_count,
    trip_distance,
    r.rate_code,
    store_and_fwd_flag,
    z_pickup.borough as pickup_borough,
    z_pickup.zone as pickup_zone,
    z_pickup.service_zone as pickup_service_zone,
    z_dropoff.borough as dropoff_borough,
    z_dropoff.zone as dropoff_zone,
    z_dropoff.service_zone as dropoff_service_zone,
    p.payment_type as payment_type,
    fare_amount,
    extra,
    mta_tax,
    tip_amount,
    tolls_amount,
    improvement_surcharge,
    total_amount,
    congestion_surcharge,
    airport_fee
from staging.taxi.yellow_tripdata as t
left join staging.taxi.taxi_zone_lookup as z_pickup on t.pulocationid = cast(z_pickup.location_id as bigint)
left join staging.taxi.taxi_zone_lookup as z_dropoff on t.dolocationid = cast(z_dropoff.location_id as bigint)
left join staging.taxi.payment_type_lookup as p on t.payment_type = cast(p.payment_type_id as bigint)
left join staging.taxi.rate_code_lookup as r on t.ratecodeid = cast(r.rate_code_id as bigint)
where tpep_pickup_datetime >= date '2015-01-01' and tpep_pickup_datetime <= now()


create or replace materialized view lakehouse.taxi.yellow_tripdata_daily_agg as
select
    date_trunc('day', tpep_pickup_datetime) as day,
    pickup_borough,
    pickup_zone,
    dropoff_borough,
    dropoff_zone,
    payment_type,
    count(*) as trips,
    avg(total_amount) as avg_total_amount,
    sum(total_amount) as sum_total_amount,
    avg(airport_fee) as avg_airport_fee,
    sum(airport_fee) as sum_airport_fee,
    avg(trip_distance) as avg_trip_distance,
    sum(trip_distance) as sum_trip_distance
from lakehouse.taxi.yellow_tripdata
group by 1, 2, 3, 4, 5, 6;


create or replace materialized view lakehouse.taxi.yellow_tripdata_monthly_agg as
select
    date_trunc('month', day) as month,
    pickup_borough,
    pickup_zone,
    dropoff_borough,
    dropoff_zone,
    payment_type,
    sum(trips) as trips,
    sum(sum_total_amount) as sum_total_amount,
    sum(sum_airport_fee) as sum_airport_fee,
    sum(sum_trip_distance) as sum_trip_distance
from lakehouse.taxi.yellow_tripdata_daily_agg
group by 1, 2, 3, 4, 5, 6


REFRESH MATERIALIZED VIEW lakehouse.taxi.yellow_tripdata_daily_agg;

REFRESH MATERIALIZED VIEW lakehouse.taxi.yellow_tripdata_monthly_agg;