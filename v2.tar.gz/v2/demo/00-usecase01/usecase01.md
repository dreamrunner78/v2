# Install KAFKA

# Create namespace
```sh
NAMESPACE=demo
kubectl create ns $NAMESPACE
k describe ns $NAMESPACE
```


# LOAD DATA
```sh
echo -n 'admin' | base64
echo -n 'DcpAdminPassword2016.' | base64
echo -n 'https://masterstorage-minio.dcp.svc.cluster.local:9000' | base64
kubectl -n $NAMESPACE apply -f yamls/s3-secret.yaml
```

```sh
kubectl create secret generic s3-credentials \
  --from-literal=accessKey=admin \
  --from-literal=secretKey=DcpAdminPassword2016.
```

# Load data 
```sh
#kubectl -n$NAMESPACE apply -f yamls/load-test-data-taxi.yaml
#kubectl -n$NAMESPACE apply -f yamls/load-test-data.yaml

kubectl -n$NAMESPACE apply -f yamls/load-test-data-offline.yaml
```

# Warehouse
- créer catalog de type objectstorage: "staging"
- créer catalog de type iceberg: "lakehouse"


# SPARK
## créate iceberg table from another table
```sql
CREATE TABLE IF NOT EXISTS sndicebergcat.raw.customer10ice
USING iceberg
OPTIONS (
    format = 'parquet'
)
LOCATION 's3a://staging/tpch/customer10ice'
AS select * from sndicebergcat.raw.customer1
```