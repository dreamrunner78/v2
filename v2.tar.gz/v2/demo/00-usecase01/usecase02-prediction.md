# Buckets
```
demo
prediction
```

# Create namespace
```sh
NAMESPACE=abe
kubectl create ns $NAMESPACE
k describe ns $NAMESPACE    
```


# LOAD DATA
```sh
echo -n 'admin' | base64
echo -n 'DcpAdminPassword2016.' | base64
echo -n 'https://masterstorage-minio.dcp.svc.cluster.local:9000' | base64
kubectl -n $NAMESPACE apply -f yamls/s3-secret.yaml
```

```sh
kubectl create secret generic s3-credentials \
  --from-literal=accessKey=admin \
  --from-literal=secretKey=DcpAdminPassword2016.
```

# Load data 
```sh
kubectl -n$NAMESPACE apply -f anomaly-detection-taxi-data/load-test-data.yaml
```
