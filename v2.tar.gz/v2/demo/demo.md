# start hms
# Create iceberg catalog
# start trino service or prestodb service
# start cache service
# offload tpcds data to bucket and load in cache

## test ICEBERG connector
```
CREATE SCHEMA IF NOT EXISTS iceberg.tpchoffload WITH (location = 's3a://data/');
CREATE TABLE iceberg.tpchoffload.customertiny
WITH (
  format = 'ORC',
  location = 's3a://data/customertiny/'
) 
AS SELECT * FROM tpch.tiny.customer

select * from iceberg.offload.customer limit 10

select * from iceberg.offload.customer order by custkey asc

  update iceberg.offload.customer set name='dcpdemo' where custkey=1
```
```

```

# start notebook service
# read data from cache and generate to another bucket using cache
```
```