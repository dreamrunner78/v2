# Notebook
1. produce to kafka
2. consume from kafak
3. execute sql trino
4. read / write to s3 buckets
5. connect to postgresql
6. connecto to hive / hdfs

# nifi


# Spark
1. read / write from iceberg catalog