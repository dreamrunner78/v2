#!/usr/bin/env python
# coding: utf-8

# In[ ]:


pip install boto3


# In[1]:


import boto3
from botocore.client import Config


# In[23]:


# Define MinIO connection details
minio_endpoint = 'https://masterstorage-minio.dcp.svc.cluster.local:9000'
minio_access_key = 'admin'
minio_secret_key = 'DcpAdminPassword2016.'
bucket_name = 'my-secured-bucket-1'
file_name = 'example.txt'
downloaded_file_name = 'downloaded_example.txt'
ca_bundle_path = '/home/test/minio.crt'  # Path to your CA bundle file


# In[24]:


# Configuring SSL
ssl_config = Config(
    #region_name='us-west-2',
    retries={
        'max_attempts': 10,
        'mode': 'standard'
    },
    s3={
        'addressing_style': 'path'
    },
    signature_version='s3v4'
)


# In[25]:


# Create an S3 client configured to use the MinIO endpoint
s3 = boto3.client(
    's3',
    endpoint_url=minio_endpoint,
    aws_access_key_id=minio_access_key,
    aws_secret_access_key=minio_secret_key,
    #config=Config(signature_version='s3'),
    config=ssl_config,
    #verify=ca_bundle_path  # Specify the CA bundle path
    verify=False
)


# In[28]:


# Create a new bucket in MinIO
def create_bucket(bucket_name):
    try:
        s3.create_bucket(Bucket=bucket_name)
        print(f'Bucket {bucket_name} created successfully.')
    except Exception as e:
        print(f'Error creating bucket: {e}')

        # Upload a file to the MinIO bucket
def upload_file(bucket_name, file_name):
    try:
        s3.upload_file(file_name, bucket_name, file_name)
        print(f'File {file_name} uploaded successfully to bucket {bucket_name}.')
    except Exception as e:
        print(f'Error uploading file: {e}')

# Download a file from the MinIO bucket
def download_file(bucket_name, file_name, downloaded_file_name):
    try:
        s3.download_file(bucket_name, file_name, downloaded_file_name)
        print(f'File {file_name} downloaded successfully as {downloaded_file_name}.')
    except Exception as e:
        print(f'Error downloading file: {e}')


# In[27]:


create_bucket(bucket_name)


# In[29]:


upload_file(bucket_name, ca_bundle_path)


# In[ ]:




