#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#pip install trino


# In[1]:


import sys
import trino


# In[2]:


if not sys.warnoptions:
        import warnings
warnings.simplefilter("ignore")


# In[6]:


def get_connection():
    connection = trino.dbapi.connect(
        host="trinosvc-trinosvcxkrlbcbnaw-svc.demo.svc.cluster.local",
        port=8443,
        user="dcpadminusername",
        http_scheme='https',
        auth=trino.auth.BasicAuthentication("dcpadminusername", open("/trino-users/dcpadminusername").read()),
        #auth=trino.auth.BasicAuthentication("dcpadminusername", "edftb8wsaa5l3hg5o8l2016."),
    )
    connection._http_session.verify = False
    return connection


# In[7]:


def run_query(connection, query):
    print(f"[DEBUG] Executing query {query}")
    cursor = connection.cursor()
    cursor.execute(query)
    return cursor.fetchall()


# In[8]:


connection = get_connection()


# In[11]:


run_query(connection, "select count(*) from tpch.tiny.nation")


# In[ ]:




