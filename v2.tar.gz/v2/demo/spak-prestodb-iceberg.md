# REF
```
https://medium.com/presto-spark-a-lakehouse-story/interoperability-presto-iceberg-spark-4e5299ec7de5
```

# Configurer spark
```
"spark.jars.packages": "org.apache.iceberg:iceberg-spark-runtime-3.5_2.12:1.5.2",
"spark.sql.extensions": "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions",
"spark.sql.catalog.hive_prod": "org.apache.iceberg.spark.SparkCatalog",
"spark.sql.catalog.hive_prod.type": "hive",
"spark.sql.catalog.hive_prod.uri": "thrift://hms-hmsqfmdyi-svc.demo.svc.cluster.local:9083",
"spark.sql.defaultCatalog": "hive_prod",
```
downloading https://repo1.maven.org/maven2/org/apache/iceberg/iceberg-spark-runtime-3.5_2.12/1.5.2/iceberg-spark-runtime-3.5_2.12-1.5.2.jar

# Test scenario 1: 
A table created in iceberg catalog by spark with data inserted by spark, is read by presto.
## Spark sql
```
spark.sql('show catalogs').show()

create schema nyc
CREATE TABLE nyc.taxis ( vendor_id bigint, trip_id bigint, trip_distance float, fare_amount double, store_and_fwd_flag string ) PARTITIONED BY (vendor_id)

INSERT INTO nyc.taxis VALUES (1, 1000371, 1.8, 15.32, 'N'), (2, 1000372, 2.5, 22.15, 'N'), (2, 1000373, 0.9, 9.01, 'N'), (1, 1000374, 8.4, 42.13, 'Y')
```


# Test scenario 2: 
1. Table created by spark,
2. Rows added by spark
3. A row added by presto.
4. Select from inserted table in both presto and spark.
```
insert into icecat.nyc.taxis values (10,1233222,2.2,12.22,'Y')
```

# Test scenario 3: 
Table created by presto and rows inserted by spark.
```sql
create table icecat.nyc.test (name varchar);
insert into icecat.nyc.test(name) values ('check')
insert into icecat.nyc.test(name) values ('check2')
select * from icecat.nyc.test;
```


# Test scenario 4:
Table created in presto and data inserted by both spark and presto in order.
```
```