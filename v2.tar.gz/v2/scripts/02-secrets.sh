#!/bin/bash

# Load environnement varaibles
. ./env.sh

# Create secret
echo '************************ START SECRET ************************'
if kubectl get secret $SECRETNAME -n $NAMESPACE &> /dev/null; then
    echo "========================Secret " $SECRETNAME " already exists.========================"
else
    echo "======================== SECRET DOES NOT EXIST. ========================"
    echo "======================== CREATE SECRET ========================"
    sed -e "\
        s#{{DNS}}#$DNS#g; \
        s#{{PREFIX}}#$PREFIX#g; \
        s#{{DOMAIN}}#$DOMAIN#g; \
        s#{{SECRETNAME}}#$SECRETNAME#g; \
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g; \
        s#{{NAMESPACE}}#$NAMESPACE#g;" $yamltemplate/secret-template.yaml > $yamldestination/secret.yaml
    if [[ $template == "false" ]]; then
        helm -n $NAMESPACE upgrade --cleanup-on-fail --install $SECRETNAME $repodir/master-tls-manager --values $yamldestination/secret.yaml
    fi
    if [ $? -eq 0 ]; then
        echo '----------------SECRET ' $SECRETNAME ' CREATED--------------------'
    else
        echo "FAILED: ERROR INSTALL DCP SECRET"
        exit 1;
    fi
fi

echo '************************ END SECRET ************************'
echo ''
echo ''

./gen-certs.sh


./create-secret.sh