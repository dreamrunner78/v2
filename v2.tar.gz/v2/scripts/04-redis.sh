#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

#REDIS
echo '************************ START ' $PREFIX ' REDIS ************************'
if [[ $enabledcpredis == "true" ]]; then
    #if kubectl get sts dcp-pgs-$dbarchitecture-postgresql -n $NAMESPACE &> /dev/null; then
    #    echo "=============================REDIS already installed============================="
    #else
    if [[ $redisarchitecture == "replication" ]]; then
        echo '=================================== Create ' $PREFIX ' REDIS REPLICATION ==================================='
        sed -e "s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{REDISPASWORD}}#$REDISPASWORD#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\

        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{REDIS_REPLICATION_REPOSITORY}}#$REDIS_REPLICATION_REPOSITORY#g;\
        s#{{REDIS_REPLICATION_VERSION}}#$REDIS_REPLICATION_VERSION#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\

        s#{{REDIS_REPLICATION_ARCHITECTURE}}#$REDIS_REPLICATION_ARCHITECTURE#g;\

        s#{{REDIS_REPLICATION_REQUESTCPU_MASTER}}#$REDIS_REPLICATION_REQUESTCPU_MASTER#g;\
        s#{{REDIS_REPLICATION_REQUESTMEMORY_MASTER}}#$REDIS_REPLICATION_REQUESTMEMORY_MASTER#g;\
        s#{{REDIS_REPLICATION_LIMITCPU_MASTER}}#$REDIS_REPLICATION_LIMITCPU_MASTER#g;\
        s#{{REDIS_REPLICATION_LIMITMEMORY_MASTER}}#$REDIS_REPLICATION_LIMITMEMORY_MASTER#g;\
        s#{{REDIS_REPLICATION_DATASIZE_MASTER}}#$REDIS_REPLICATION_DATASIZE_MASTER#g;\

        s#{{REDIS_REPLICATION_USER}}#$REDIS_REPLICATION_USER#g;\
        
        s#{{REDIS_REPLICATION_REQUESTCPU_WORKER}}#$REDIS_REPLICATION_REQUESTCPU_WORKER#g;\
        s#{{REDIS_REPLICATION_REQUESTMEMORY_WORKER}}#$REDISUREDIS_REPLICATION_REQUESTMEMORY_WORKERSER#g;\
        s#{{REDIS_REPLICATION_LIMITCPU_WORKER}}#$REDIS_REPLICATION_LIMITCPU_WORKER#g;\
        s#{{REDIS_REPLICATION_LIMITMEMORY_WORKER}}#$REDIS_REPLICATION_LIMITMEMORY_WORKER#g;\
        s#{{REDIS_REPLICATION_DATASIZE_WORKER}}#$REDIS_REPLICATION_DATASIZE_WORKER#g;\

        s#{{REDISREPLICATION_ENABLE_AUTOSCALING}}#$REDISREPLICATION_ENABLE_AUTOSCALING#g;\
        s#{{REDISREPLICATION_ENABLE_MINREPLICAS}}#$REDISREPLICATION_ENABLE_MINREPLICAS#g;\
        s#{{REDISREPLICATION_ENABLE_MAXREPLICAS}}#$REDISREPLICATION_ENABLE_MAXREPLICAS#g;\
        s#{{REDISREPLICATION_ENABLE_TARGETCPU}}#$REDISREPLICATION_ENABLE_TARGETCPU#g;\
        s#{{REDISREPLICATION_ENABLE_TARGETMEMORY}}#$REDISREPLICATION_ENABLE_TARGETMEMORY#g;\

        s#{{REDIS_REPLICATION_REPLICACOUNT_WORKER}}#$REDIS_REPLICATION_REPLICACOUNT_WORKER#g;\
        s#{{REDIS_REPLICATION_SCHEDULERNAME}}#$REDIS_REPLICATION_SCHEDULERNAME#g;" $yamltemplate/redis-template.yaml > $yamldestination/dcp-redis.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaseredis $repodir/redis --values $yamldestination/dcp-redis.yaml
        fi
        
        echo '===================================' $PREFIX ' REDIS CREATED ==================================='
    
    elif [[ $redisarchitecture == "cluster" ]]; then

        echo '=================================== Create ' $PREFIX ' REDIS CLUSTER ==================================='
        sed -e "s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{REDISPASWORD}}#$REDISPASWORD#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\

        s#{{REDIS_CLUSTER_REPOSITORY}}#$REDIS_CLUSTER_REPOSITORY#g;\
        s#{{REDIS_CLUSTER_VERSION}}#$REDIS_CLUSTER_VERSION#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{REDIS_CLUSTER_USER}}#$REDIS_CLUSTER_USER#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{REDIS_CLUSTER_REQUESTCPU}}#$REDIS_CLUSTER_REQUESTCPU#g;\
        s#{{REDIS_CLUSTER_REQUESTMEMORY}}#$REDIS_CLUSTER_REQUESTMEMORY#g;\
        s#{{REDIS_CLUSTER_LIMITCPU}}#$REDIS_CLUSTER_LIMITCPU#g;\
        s#{{REDIS_CLUSTER_LIMITMEMORY}}#$REDIS_CLUSTER_REQUESTMEMORY#g;\
        s#{{REDIS_CLUSTER_DATASIZE}}#$REDIS_CLUSTER_DATASIZE#g;\
        s#{{REDIS_CLUSTER_NODES}}#$REDIS_CLUSTER_NODES#g;\
        s#{{REDIS_CLUSTER_REPLICAS}}#$REDIS_CLUSTER_REPLICAS#g;\
        s#{{REDIS_CLUSTER_SCHEDULERNAME}}#$REDIS_CLUSTER_SCHEDULERNAME#g;" $yamltemplate/redis-cluster-template.yaml > $yamldestination/redis-cluster.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaseredis $repodir/redis-cluster --values $yamldestination/redis-cluster.yaml
        fi
        
        echo '===================================' $PREFIX ' REDIS CREATED ==================================='
    fi
    #fi
else
    echo '===================================' $PREFIX ' REDIS DISABLED ==================================='
fi
echo '************************ END ' $PREFIX ' REDIS ************************'