#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh


# DATABASE
echo '************************ START ' $PREFIX ' DATABASE ************************'
if [[ $createdatabase == "true" ]]; then
    if kubectl get sts $releasepgs-$dbarchitecture-postgresql -n $NAMESPACE &> /dev/null; then
        echo '============================= ' $PREFIX ' DATABASE ALREADY INSTALLED ============================='
    else
        if [[ $dbarchitecture == "ha" ]]; then            
            echo '=================================== CREATING' $PREFIX  ' H.A. DATABASE ==================================='
            sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
            s#{{PREFIX}}#$PREFIX#g;\
            s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
            s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
            s#{{KUBEVERSION}}#$KUBEVERSION#g;\
            s#{{PULLPOLICY}}#$PULLPOLICY#g;\
            s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
            s#{{RUNASUSER}}#$RUNASUSER#g;\
            s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
            
            s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
            s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
            s#{{REDIS_SERVICENAME}}#$REDIS_SERVICENAME#g;\

            s#{{COMMONLABELS}}#$COMMONLABELS#g;\
            s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
            
            s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
            
            s#{{PGS_PERSISTENCE_ENABLED}}#$PGS_PERSISTENCE_ENABLED#g;\
            s#{{PGS_DATA_SIZE}}#$PGS_DATA_SIZE#g;\
            s#{{PGS_REPOSITORY}}#$PGS_REPOSITORY#g;\
            s#{{PGS_VERSION}}#$PGS_VERSION#g;\
            s#{{PGS_REPLICACOUNT}}#$PGS_REPLICACOUNT#g;\
            s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
            s#{{PGS_REQUEST_CPU}}#$PGS_REQUEST_CPU#g;\
            s#{{PGS_REQUEST_MEMORY}}#$PGS_REQUEST_MEMORY#g;\
            s#{{PGS_LIMIT_CPU}}#$PGS_LIMIT_CPU#g;\
            s#{{PGS_LIMIT_MEMORY}}#$PGS_LIMIT_MEMORY#g;\
            s#{{PGS_PDB_ENABLED}}#$PGS_PDB_ENABLED#g;\
            s#{{PGS_PDB_MINAVAILABLE}}#$PGS_PDB_MINAVAILABLE#g;\
            s#{{PGS_PDB_MAXUNAVAILABLE}}#$PGS_PDB_MAXUNAVAILABLE#g;\
            s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
            s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
            s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
            s#{{PGS_ROOTPASSWORD}}#$PGS_ROOTPASSWORD#g;\
            
            s#{{PGS_PGPOOL_REPOSITORY}}#$PGS_PGPOOL_REPOSITORY#g;\
            s#{{PGS_PGPOOL_VERSION}}#$PGS_PGPOOL_VERSION#g;\
            s#{{PGS_REPLICACOUNT}}#$PGS_REPLICACOUNT#g;\
            s#{{PGS_PGPOOL_REQUEST_CPU}}#$PGS_PGPOOL_REQUEST_CPU#g;\
            s#{{PGS_PGPOOL_REQUEST_MEMORY}}#$PGS_PGPOOL_REQUEST_MEMORY#g;\
            s#{{PGS_PGPOOL_LIMIT_CPU}}#$PGS_PGPOOL_LIMIT_CPU#g;\
            s#{{PGS_PGPOOL_LIMIT_MEMORY}}#$PGS_PGPOOL_LIMIT_MEMORY#g;\
            s#{{PGS_PGPOOL_PDB_ENABLED}}#$PGS_PGPOOL_PDB_ENABLED#g;\
            s#{{PGS_PGPOOL_PDB_MINAVAILABLE}}#$PGS_PGPOOL_PDB_MINAVAILABLE#g;\
            s#{{PGS_PGPOOL_PDB_MAXUNAVAILABLE}}#$PGS_PGPOOL_PDB_MAXUNAVAILABLE#g;\

            s#{{PGS_PGPOOL_NUMINITCHILDREN}}#$PGS_PGPOOL_NUMINITCHILDREN#g;\
            s#{{PGS_PGPOOL_RESERVEDCONNECTIONS}}#$PGS_PGPOOL_RESERVEDCONNECTIONS#g;\
            s#{{PGS_PGPOOL_MAXPOOL}}#$PGS_PGPOOL_MAXPOOL#g;\
            s#{{PGS_PGPOOL_CHILDMAXCONNECTIONS}}#$PGS_PGPOOL_CHILDMAXCONNECTIONS#g;\
            s#{{PGS_PGPOOL_CHILDLIFETIME}}#$PGS_PGPOOL_CHILDLIFETIME#g;\
            s#{{PGS_PGPOOL_CLIENTIDLELIMIT}}#$PGS_PGPOOL_CLIENTIDLELIMIT#g;\
            s#{{PGS_PGPOOL_CONNECTIONLIFETIME}}#$PGS_PGPOOL_CONNECTIONLIFETIME#g;\


            s#{{DIRVALUES}}#$DIRVALUES#g;\
            s#{{UPLOADDIRECTORY}}#$UPLOADDIRECTORY#g;\
            s#{{NAMESPACE}}#$NAMESPACE#g;\
            s#{{REDISPASWORD}}#$REDISPASWORD#g;\
            s#{{DCPSTORAGEACCESSKEY}}#$DCPSTORAGEACCESSKEY#g;\
            s#{{DCPSTORAGESECRETKEY}}#$DCPSTORAGESECRETKEY#g;\
            s#{{CREATESPARKHISTORYPATH}}#$CREATESPARKHISTORYPATH#g;\
            s#{{USERKEYCLOAKSERVICENAME}}#$USERKEYCLOAKSERVICENAME#g;\
            s#{{KUBEHOST}}#$KUBEHOST#g;\
            s#{{KUBEPORT}}#$KUBEPORT#g;\
            s#{{KUBEDNS}}#$KUBEDNS#g;\
            s#{{KUBELOG}}#$KUBELOG#g;\
            s#{{LDAP_URL}}#$LDAP_URL#g;\
            s#{{ROOTREPO}}#$ROOTREPO#g;" $yamltemplate/postgresql-ha-template.yaml > $yamldestination/postgresql-ha.yaml

            if [[ $template == "false" ]]; then
                helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasepgs $repodir/postgresql-ha --values $yamldestination/postgresql-ha.yaml
            fi

            echo '=================================== ' $PREFIX  ' H.A. DATABASE CREATED ==================================='
        elif [[ $dbarchitecture == "replication" ]]; then            
            echo '=================================== CREATING' $PREFIX  ' REPLICATION DATABASE ==================================='
            sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
            s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
            s#{{PREFIX}}#$PREFIX#g;\
            s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
            s#{{KUBEVERSION}}#$KUBEVERSION#g;\
            s#{{PULLPOLICY}}#$PULLPOLICY#g;\
            s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
            s#{{RUNASUSER}}#$RUNASUSER#g;\
            s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\

            s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
            s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
            s#{{REDIS_SERVICENAME}}#$REDIS_SERVICENAME#g;\

            s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\

            s#{{COMMONLABELS}}#$COMMONLABELS#g;\
            s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
            
            s#{{PGS_ROOTPASSWORD}}#$PGS_ROOTPASSWORD#g;\
            s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
            s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
            s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
            
            s#{{PGS_REPLICATION_REPLICACOUNT}}#$PGS_REPLICATION_REPLICACOUNT#g;\
            s#{{PGS_REPLICATION_ARCHITECTURE}}#$PGS_REPLICATION_ARCHITECTURE#g;\
            
            s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
            s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
            
            s#{{PGS_REPLICATION_REQUESTCPU}}#$PGS_REPLICATION_REQUESTCPU#g;\
            s#{{PGS_REPLICATION_REQUESTMEMORY}}#$PGS_REPLICATION_REQUESTMEMORY#g;\
            s#{{PGS_REPLICATION_LIMITCPU}}#$PGS_REPLICATION_LIMITCPU#g;\
            s#{{PGS_REPLICATION_LIMITMEMORY}}#$PGS_REPLICATION_LIMITMEMORY#g;\

            s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
            s#{{PGS_PERSISTENCE_ENABLED}}#$PGS_PERSISTENCE_ENABLED#g;\
            s#{{PGS_DATA_SIZE}}#$PGS_DATA_SIZE#g;\

            s#{{DIRVALUES}}#$DIRVALUES#g;\
            s#{{UPLOADDIRECTORY}}#$UPLOADDIRECTORY#g;\
            s#{{NAMESPACE}}#$NAMESPACE#g;\
            s#{{REDISPASWORD}}#$REDISPASWORD#g;\
            s#{{DCPSTORAGEACCESSKEY}}#$DCPSTORAGEACCESSKEY#g;\
            s#{{DCPSTORAGESECRETKEY}}#$DCPSTORAGESECRETKEY#g;\
            s#{{CREATESPARKHISTORYPATH}}#$CREATESPARKHISTORYPATH#g;\
            s#{{USERKEYCLOAKSERVICENAME}}#$USERKEYCLOAKSERVICENAME#g;\
            s#{{KUBEHOST}}#$KUBEHOST#g;\
            s#{{KUBEPORT}}#$KUBEPORT#g;\
            s#{{KUBEDNS}}#$KUBEDNS#g;\
            s#{{KUBELOG}}#$KUBELOG#g;\
            s#{{LDAP_URL}}#$LDAP_URL#g;\
            s#{{ROOTREPO}}#$ROOTREPO#g;" $yamltemplate/postgresql-replication-template.yaml > $yamldestination/postgresql-replication.yaml

            if [[ $template == "false" ]]; then
                helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasepgs $repodir/postgresql --values $yamldestination/postgresql-replication.yaml
            fi

            echo '=================================== ' $PREFIX  ' REPLICATION DATABASE CREATED ==================================='
        fi
    fi
else
    echo '=================================== ' $PREFIX  ' DATABASE DISABLED==================================='
fi
echo '************************ END ' $PREFIX ' DATABASE ************************'
echo ''
echo ''