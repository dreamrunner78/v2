#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

echo '************************ START ' $PREFIX ' MODEL ************************'
if [[ $createdcpapi == "true" ]]; then
echo '=================================== CREATING' $PREFIX  ' MODEL ==================================='
sed -e "s#{{MASTER_NAME}}#$MASTER_NAME#g;\
s#{{NAMESPACE}}#$NAMESPACE#g;\
s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
s#{{MASTER_KEYSTORE_PATH}}#$MASTER_KEYSTORE_PATH#g;\
s#{{PREFIX}}#$PREFIX#g;\
s#{{MASTER_KEYSTORE_PASSWORD}}#$MASTER_KEYSTORE_PASSWORD#g;" $yamltemplate/master-model-template.yaml > $yamldestination/master-model.yaml

sed -e "s#{{MASTER_NAME}}#$MASTER_NAME#g;\
s#{{COMMONLABELSHEIGHT}}#$COMMONLABELSHEIGHT#g;\
s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
s#{{REGISTRY}}#$REGISTRY#g;\
s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
s#{{PULLPOLICY}}#$PULLPOLICY#g;\
s#{{RUNASUSER}}#$RUNASUSER#g;\
s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
s#{{NAMESPACE}}#$NAMESPACE#g;\
s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
s#{{REGISTRY}}#$REGISTRY#g;\
s#{{MASTER_REPOSITORY}}#$MASTER_REPOSITORY#g;\
s#{{MASTER_VERSION}}#$MASTER_VERSION#g;\
s#{{SECRETNAME}}#$SECRETNAME#g;\
s#{{PREFIX}}#$PREFIX#g;\
s#{{MASTER_KEYSTORE_PASSWORD}}#$MASTER_KEYSTORE_PASSWORD#g;" $yamltemplate/master-model-job-template.yaml > $yamldestination/master-model-job.yaml

if [[ $template == "false" ]]; then
kubectl -n $NAMESPACE apply -f $yamldestination/master-model.yaml
sleep 3
kubectl -n $NAMESPACE delete -f $yamldestination/master-model-job.yaml
sleep 3
kubectl -n $NAMESPACE apply -f $yamldestination/master-model-job.yaml
fi

echo '=================================== ' $PREFIX  ' MODEL DEPLOYED ==================================='

else
    echo '=================================== ' $PREFIX  ' MODEL DISABLED==================================='
fi

echo '************************ END ' $PREFIX ' MODEL ************************'