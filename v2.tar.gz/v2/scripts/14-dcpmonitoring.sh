#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

#MASTER
echo '************************ START ' $PREFIX ' MONITORNG ************************'
if [[ $createdcpmonitoring == "true" ]]; then
    if kubectl get sts $releasemastermonitoring -n $NAMESPACE &> /dev/null; then
        echo '============================= ' $PREFIX ' MONITORNG ALREADY INSTALLED ============================='
    else
        echo '=================================== CREATING' $PREFIX  ' MONITORNG ==================================='
        sed -e "s#{{MN_NAME}}#$MN_NAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{PREFIX}}#$PREFIX#g;\
        s#{{MASTER_HOSTALIASES}}#$MASTER_HOSTALIASES#g;\
        s#{{MASTER_DNSCONFIG}}#$MASTER_DNSCONFIG#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{MN_REPOSITORY}}#$MN_REPOSITORY#g;\
        s#{{MN_EXPORTER_TAG}}#$MN_EXPORTER_TAG#g;\
        s#{{MN_RETENTION}}#$MN_RETENTION#g;\
        s#{{MN_RETENTIONSIZE}}#$MN_RETENTIONSIZE#g;\
        s#{{MN_DATASIZE}}#$MN_DATASIZE#g;\
        s#{{MN_EXPORTER_REQUESTCPU}}#$MN_EXPORTER_REQUESTCPU#g;\
        s#{{MN_EXPORTER_REQUESTMEMORY}}#$MN_EXPORTER_REQUESTMEMORY#g;\
        s#{{MN_EXPORTER_LIMITCPU}}#$MN_EXPORTER_LIMITCPU#g;\
        s#{{MN_EXPORTER_LIMITMEMORY}}#$MN_EXPORTER_LIMITMEMORY#g;\
        s#{{MN_REPOSITORY}}#$MN_REPOSITORY#g;\
        s#{{MN_DASHBOARD_TAG}}#$MN_DASHBOARD_TAG#g;\
        s#{{MN_DASHBOARD_REQUESTCPU}}#$MN_DASHBOARD_REQUESTCPU#g;\
        s#{{MN_DASHBOARD_REQUESTMEMORY}}#$MN_DASHBOARD_REQUESTMEMORY#g;\
        s#{{MN_DASHBOARD_LIMITCPU}}#$MN_DASHBOARD_LIMITCPU#g;\
        s#{{MN_DASHBOARD_LIMITMEMORY}}#$MN_DASHBOARD_LIMITMEMORY#g;\
        s#{{DOMAIN}}#$DOMAIN#g;\
        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/master-monitoring-template.yaml > $yamldestination/master-monitoring.yaml

        echo "" >> $yamldestination/master-monitoring.yaml
        echo "certificate: |" >> $yamldestination/master-monitoring.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/master-monitoring.yaml
        done
        echo "key: |-" >> $yamldestination/master-monitoring.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/master-monitoring.yaml
        done
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemastermonitoring $repodir/master-monitoring --values $yamldestination/master-monitoring.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo '=================================== ' $PREFIX  ' MONITORNG CREATED ==================================='
    fi
else
    echo '=================================== ' $PREFIX  ' MONITORNG DISABLED==================================='
fi

echo '************************ END ' $PREFIX ' MONITORNG ************************'
echo ''
echo ''