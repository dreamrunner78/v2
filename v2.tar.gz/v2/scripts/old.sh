repodir=$(pwd)/repos
yamltemplate=$(pwd)/templates
yamldestination=$(pwd)/yamls

#template: true ==> create only tepmlate | false=: install service
template="false"

#DCP namespace
createnamepace="false"

#DATABASE
createdatabase="false"
dbarchitecture="replication" # replication or ha
releasepgs="masterdb"

#INIT DATABASE
initdatabase="false"

#DCP API
createdcpapi="true"
releasemaster="masterapi"

#DCP PROXY
enabledcpproxy="false"
releasemasterproxy=masterproxy

#DCP SCHEDULER
createdcpscheduler="false"
releasescheduler=masterscheduler

#DCP STORAGE
enabledcpstorage="false"
releasestorage=masterstorage

#DCP REDIS
enabledcpredis="false"
redisarchitecture="replication" # replication or cluster
releaseredis="masterredis"

#DCP LOG STACK
enablelogstack="false"
createdcpgrafana="false"
releaselogstack="loki"

#GLOBAL
ISOPENSHIFT=true
REGISTRY=docker.io
REPOSITORY=dcptechnologies
PULLPOLICY=IfNotPresent
IMAGEPULLSECRET="dcpregistry"
NINXCLASS=nginx
USEINGRESSCLASSNAME=false
DEFAULT_CLOUD_NAME=local
INIT_IMAGE="$REGISTRY/$REPOSITORY/java:17-jre"

KUBEVERSION=""
NAMESPACE=dcp
STORAGECLASSNAME=standard
ENABLEOSROOT=false
ENABLEINGRESS=true
DOMAIN=test
INGRESSHOSTNAME=dcp.$DOMAIN
RUNASUSER=1001
READONLYROOTFILESYSTEM=true
CLUSTERDOMAIN=svc.cluster.local

COMMONLABELS="" #"label1: val1\n  label2: val2"
COMMONLABELSHEIGHT="" #"        label1: val1\n        label2: val2"
COMMONANNOTATIONS=""
CERT_MANAGER_DNSNAMES="\n    - \"*.*-headless.*.svc.cluster.local\"\n    - \"*.svc.cluster.local\"\n    - \"*.*.*.svc.cluster.local\"\n    - \"*.*.svc.cluster.local\"\n    - \"localhost\"\n    - \"*.$DOMAIN\""


#LDAP
LDAP_SECURED=false
LDAP_FACTORY=com.sun.jndi.ldap.LdapCtxFactory
LDAP_URL=ldap://ldap.dcp.svc.cluster.local:1389
LDAP_PRINCIPAL=cn=%s,ou=Users,dc=example,dc=org
LDAP_GIVENNAME=givenname
LDAP_SHORTNAME=sn
LDAP_EMAIL=email
LDAP_GROUP=ou
LDAP_UID=uid
LDAP_VIEWALLATTRIBUTES=true
LDAP_FILTERSEARCH="(\&(objectClass=person)(cn="%s"))"
LDAP_SEARCHMETHOD=bind # bind, user
LDAP_CANGETATTRIBUTE=false
LDAP_SCOPELEVEL=2
LDAP_AUTHENTICATIONTYPE=simple # simle, none
LDAP_BINDDN=cn=admin,dc=example,dc=org
LDAP_BINDPASSWORD=bassim
LDAP_ATTRIBUTES=givenname,sn,email,ou,uid
LDAP_BINDFILTERSEARCH=(objectClass=*)

#SECRET
DNS="*.$DOMAIN"
SECRETNAME=mastersecret

# LOG
LOKI_REPOSITORY=$REGISTRY/$REPOSITORY/log
LOKI_VERSION=loki-2.6.1
LOKI_REQUEST_CPU=100m
LOKI_REQUEST_MEM=128Mi
LOKI_LIMIT_CPU=1
LOKI_LIMIT_MEM=1G
LOKI_PERSISSTENCE_ENABLED=true
LOKI_PERSISSTENCE_SIZE=1Gi
LOKI_PERSISSTENCE_S3=false

PROMTAIL_REPOSITORY=$REPOSITORY/log
PROMTAIL_VERSION=promtail-v1
PROMTAIL_DAEMON=true
PROMTAIL_DEPLOYMENT=false
PROMTAIL_DEPLOYMENT_REPLICAS=5
PROMTAIL_REQUEST_CPU=100m
PROMTAIL_REQUEST_MEM=128Mi
PROMTAIL_LIMIT_CPU=1
PROMTAIL_LIMIT_MEM=1G

GRAFANA_NAME=dcpgrafana
GRAFANA_REPOSITORY=$REPOSITORY/log
GRAFANA_VERSION=grafana-8.3.5
GRAFANA_REQUEST_CPU=100m
GRAFANA_REQUEST_MEM=128Mi
GRAFANA_LIMIT_CPU=1
GRAFANA_LIMIT_MEM=1G

#DATABASE
PGS_REPLICATION_REPOSITORY=$REPOSITORY/pgs
PGS_REPLICATION_VERSION=replication-16.1.0-debian-11-r15
PGS_REPLICATION_ARCHITECTURE=standalone #PostgreSQL architecture (`standalone` or `replication`)
PGS_REPLICATION_REPLICACOUNT=3
PGS_REPLICATION_REQUESTCPU=500m
PGS_REPLICATION_REQUESTMEMORY=256Mi
PGS_REPLICATION_LIMITCPU=2
PGS_REPLICATION_LIMITMEMORY=2048Mi
PGS_PERSISTENCE_ENABLED=true
PGS_DATA_SIZE=8Gi

PGS_SERVICENAME=$releasepgs-postgresql
if [[ $dbarchitecture == "ha" ]]; then
    PGS_SERVICENAME=$releasepgs-postgresql-ha-pgpool
fi
if [[ $PGS_REPLICATION_ARCHITECTURE == "replication" ]]; then
    PGS_SERVICENAME=$releasepgs-postgresql-primary
fi

#H.A.
PGS_REPOSITORY=$REPOSITORY/pgs
PGS_VERSION=repmgr-16.1.0-debian-11-r10
PGS_REPLICACOUNT=3
PGS_REQUEST_CPU=100m
PGS_REQUEST_MEMORY=256Mi
PGS_LIMIT_CPU=500m
PGS_LIMIT_MEMORY=512Mi
PGS_PDB_ENABLED=false
PGS_PDB_MINAVAILABLE=1
PGS_PDB_MAXUNAVAILABLE=""

PGS_USERNAME=dcp
PGS_PASSWORD=dcp
PGS_DATABASE=dcp
PGS_ROOTPASSWORD=AdminPassword2016

PGS_PGPOOL_REPOSITORY=$REPOSITORY/pgs
PGS_PGPOOL_VERSION=pgpool-4.4.5-debian-11-r0
PGS_PGPOOL_REQUEST_CPU=100m
PGS_PGPOOL_REQUEST_MEMORY=512Mi
PGS_PGPOOL_LIMIT_CPU=500m
PGS_PGPOOL_LIMIT_MEMORY=1024Mi
PGS_PGPOOL_PDB_ENABLED=false
PGS_PGPOOL_PDB_MINAVAILABLE=1
PGS_PGPOOL_PDB_MAXUNAVAILABLE=""
PGS_PGPOOL_NUMINITCHILDREN="64"
PGS_PGPOOL_RESERVEDCONNECTIONS=1
PGS_PGPOOL_MAXPOOL=""
PGS_PGPOOL_CHILDMAXCONNECTIONS=""
PGS_PGPOOL_CHILDLIFETIME="0"
PGS_PGPOOL_CLIENTIDLELIMIT=""
PGS_PGPOOL_CONNECTIONLIFETIME="20000"

DIRVALUES=/data/values/
UPLOADDIRECTORY=/data/upload/
ROOTREPO=/data/repo/
CREATESPARKHISTORYPATH=true
USERKEYCLOAKSERVICENAME=true
KUBEHOST=
KUBEPORT=443
KUBEDNS=.$DOMAIN
KUBELOG=dcp/log-service


#DCPAPI
MASTER_HOSTALIASES=""
MASTER_DNSCONFIG=""
MASTER_NAME=api
MASTER_REPLICACOUNT=1
MASTER_ALLINONEPOD=true
LOGWATCHER_SERVICENAME=$releasemaster-svc
if [[ $MASTER_ALLINONEPOD == "false" ]]; then
    LOGWATCHER_SERVICENAME=$releasemaster-log-svc
fi

MASTER_API_VERSION=1.0.30
MASTER_REPOSITORY=$REPOSITORY/api
MASTER_VERSION=1.0.30

MASTER_LOGLEVEL=INFO
MASTER_ENABLE_AUTOSCALING=false
MASTER_MINREPLICAS=1
MASTER_MAXREPLICAS=6
MASTER_TARGETCPU=50
MASTER_TARGETMEMORY=80

MASTER_SERVICE_ACCOUNT=master-sa
MASTER_CLUSTER_ROLE=true #false
#MASTER_NAMESPACES="\n    - dcp\n    - ns1\n    - ns2\n    - ns3"
MASTER_NAMESPACES=""

MASTER_SSL_ENABLED=false
MASTER_SSL_AUTOGENERATED=true
MASTER_KEYSTORE_PATH=/opt/dcp/keystore/dcp-keystore.jks
MASTER_KEYSTORE_PASSWORD=dcp20162018
MASTER_TRUSTSTORE_PATH=/opt/dcp/keystore/dcp-truststore.jks
MASTER_INIT_REQUESTCPU=500m
MASTER_INIT_REQUESTMEMORY=512Mi
MASTER_INIT_LIMITCPU=1
MASTER_INIT_LIMITMEMORY=1G

MASTER_PGS_CONNECTION_TIMEOUT=20000
MASTER_PGS_MAXIMUMPOOLSIZE=10

#MASTER_EXTRAS_FILES="\n    - ldap.cert\n    - storage.cert\n"
MASTER_EXTRAS_FILES="\n    - storage.cert\n"
#MASTER_EXTRAS_FILES=""
#MASTER_EXTRAS_HOSTNAMES="\n    - dcp-storage-minio.dcp.svc.cluster.local:9000"
MASTER_EXTRAS_HOSTNAMES=""

MASTER_REQUESTCPU=500m
MASTER_REQUESTMEMORY=1Gi
MASTER_LIMITCPU=4
MASTER_LIMITMEMORY=4G
MASTER_PERSISTENCE_ENABLED=true
MASTER_PERSISTENCE_SIZE=8Gi

LOGWATCHER_REQUESTCPU=500m
LOGWATCHER_REQUESTMEMORY=512Mi
LOGWATCHER_LIMITCPU=1
LOGWATCHER_LIMITMEMORY=2048Mi

PODWATCHER_CLEANPODS=true
WATCHER_NAMESPACES=""
PODWATCHER_REQUESTCPU=500m
PODWATCHER_REQUESTMEMORY=512Mi
PODWATCHER_LIMITCPU=1
PODWATCHER_LIMITMEMORY=2048Mi
#PODWATCHER_NAMESPACES="ns1,ns2,ns3"
PODWATCHER_NAMESPACES=""

HEALTH_HEARTBEAT=5
HEALTH_DELAY=5
HEALTH_REQUESTCPU=500m
HEALTH_REQUESTMEMORY=512Mi
HEALTH_LIMITCPU=1
HEALTH_LIMITMEMORY=2048Mi

#DCP REDIS CLUSTER
REDISPASWORD=dcpadmin2016

REDIS_CLUSTER_REPOSITORY=$REPOSITORY/redis
REDIS_CLUSTER_VERSION=cluster-7.2.3-debian-11-r1
REDIS_CLUSTER_REQUESTCPU=500m
REDIS_CLUSTER_LIMITCPU=500m
REDIS_CLUSTER_REQUESTMEMORY=512Mi
REDIS_CLUSTER_LIMITMEMORY=1024Mi
REDIS_CLUSTER_SCHEDULERNAME=""
REDIS_CLUSTER_DATASIZE=6Gi
#The number of master nodes should always be >= 3, otherwise cluster creation will fail
#nodes = numberOfMasterNodes + numberOfMasterNodes * replicas
REDIS_CLUSTER_NODES=6
#NUMBER OF REPLICAS PER MASTER
REDIS_CLUSTER_REPLICAS=1

#DCP REDIS REPLICATION
REDIS_REPLICATION_REPOSITORY=$REPOSITORY/redis
REDIS_REPLICATION_VERSION=replication-7.2.3-debian-11-r1

REDIS_REPLICATION_REQUESTCPU_MASTER=500m
REDIS_REPLICATION_LIMITCPU_MASTER=1
REDIS_REPLICATION_REQUESTMEMORY_MASTER=512Mi
REDIS_REPLICATION_LIMITMEMORY_MASTER=2048Mi
REDIS_REPLICATION_DATASIZE_MASTER=6Gi

REDIS_REPLICATION_ARCHITECTURE=standalone # replication | standalone
REDIS_REPLICATION_REPLICACOUNT_WORKER=3
REDIS_REPLICATION_REQUESTCPU_WORKER=500m
REDIS_REPLICATION_LIMITCPU_WORKER=1
REDIS_REPLICATION_REQUESTMEMORY_WORKER=512Mi
REDIS_REPLICATION_LIMITMEMORY_WORKER=2048Mi
REDIS_REPLICATION_DATASIZE_WORKER=6Gi

REDISREPLICATION_ENABLE_AUTOSCALING=false
REDISREPLICATION_ENABLE_MINREPLICAS=1
REDISREPLICATION_ENABLE_MAXREPLICAS=11
REDISREPLICATION_ENABLE_TARGETCPU=70
REDISREPLICATION_ENABLE_TARGETMEMORY=80

REDIS_REPLICATION_SCHEDULERNAME=""

REDIS_SERVICENAME=$releaseredis-master
if [[ $redisarchitecture == "cluster" ]]; then
    REDIS_SERVICENAME=$releaseredis-redis-cluster
fi

#PROXY
PROXYNAME=$releasemasterproxy
PROXY_REPOSITORY=$REPOSITORY/proxy
PROXY_VERSION=1.0.0
PROXYREPLICACOUNT=1
PROXYSERVICEACCOUNT=master-proxy-sa
PROXYREQUESTCPU=500m
PROXYLIMITCPU=1
PROXYREQUESTMEMORY=256Mi
PROXYLIMITMEMORY=1024Mi
PROXYSCHEDULERNAME=""

#DCP STORAGE
STORAGE_MODE=standalone # (`standalone` or `distributed`)
STORAGE_REPLICACOUNT=2
STORAGE_DRIVESPERNODE=2

STORAGE_REPOSITORY=$REPOSITORY/minio
STORAGE_VERSION=2023.11.20-debian-11-r0
STORAGE_REPOSITORY_CLIENT=$REPOSITORY/minio
STORAGE_VERSION_CLIENT=client-2023.11.20-debian-11-r0

STORAGE_SSL_ENABLED=true

STORAGE_ACCESSKEY=admin
STORAGE_SECRETKEY=DcpAdminPassword2016.

STORAGE_PERSISTNECE_ENABLED=true
STORAGE_SIZE=16Gi

STORAGE_REQUESTCPU=500m
STORAGE_LIMITCPU=2
STORAGE_REQUESTMEMORY=512Mi
STORAGE_LIMITMEMORY=2048Mi

STORAGE_HOSTNAME=storage.$DOMAIN


#DCP SCHEDULER
SCHEDULER_REPOSITORY=$REPOSITORY/yunikorn
SCHEDULER_VERSION=scheduler-1.4.0
SCHEDULER_REQUESTCPU=500m
SCHEDULER_LIMITCPU=4
SCHEDULER_REQUESTMEMORY=1Gi
SCHEDULER_LIMITMEMORY=2Gi
SCHEDULER_ENABLEOSROOT=false
SCHEDULER_ENABLEINGRESS=false
SCHEDULER_INGRESSHOSTNAME=dcpscheduler.$DOMAIN

PLUGIN_REPOSITORY=$REPOSITORY/yunikorn
PLUGIN_VERSION=scheduler-plugin-1.4.0

ADMISSION_REPOSITORY=$REPOSITORY/yunikorn
ADMISSION_VERSION=admission-1.4.0
ADMISSION_REQUESTCPU=500m
ADMISSION_LIMITCPU=2
ADMISSION_REQUESTMEMORY=512Mi
ADMISSION_LIMITMEMORY=1Gi

WEB_REPOSITORY=$REPOSITORY/yunikorn
WEB_VERSION=web-1.4.0
WEB_REQUESTCPU=500m
WEB_LIMITCPU=1
WEB_REQUESTMEMORY=512Mi
WEB_LIMITMEMORY=1Gi

# Create namespace
echo '************************START DCP namespace************************'
if [[ $createnamepace == "true" ]]; then
    echo '----------------Create DCP namespace--------------------'
    if kubectl get namespaces | grep -q $NAMESPACE; then   
        echo 'DCP namespace already exist'
    else
        if [[ $template == "false" ]]; then
            kubectl create ns $NAMESPACE
        fi
        echo 'DCP namespace created'
    fi
else
    echo '----------------IGNORE CREATING NAMESPACE--------------------'
fi
echo '************************END DCP namespace************************'
echo ''
echo ''

# Create secrets
echo '************************START DCP SECRET************************'
if kubectl get secret $SECRETNAME -n $NAMESPACE &> /dev/null; then
    echo "========================Secret " $SECRETNAME " already exists.========================"
else
    echo "========================Secret does not exist.========================"
    echo "========================Create DCP SECRET========================"
    sed -e "\
        s#{{DNS}}#$DNS#g; \
        s#{{DOMAIN}}#$DOMAIN#g; \
        s#{{SECRETNAME}}#$SECRETNAME#g; \
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g; \
        s#{{NAMESPACE}}#$NAMESPACE#g;" $yamltemplate/secret-template.yaml > $yamldestination/secret.yaml
    if [[ $template == "false" ]]; then
        helm -n $NAMESPACE upgrade --cleanup-on-fail --install $SECRETNAME $repodir/master-tls-manager --values $yamldestination/secret.yaml
    fi
    if [ $? -eq 0 ]; then
        echo '----------------SECRET ' $SECRETNAME ' CREATED--------------------'
    else
        echo "FAILED: error install DCP SECRET"
        exit 1;
    fi
fi

CACERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["ca.crt"]')
CAKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["ca.key"]')
TLSCERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.crt"]')
TLSKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.key"]')

CERTIFICATE=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.crt"]' | base64 --decode)
KEYCERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.key"]' | base64 --decode)
echo '************************END DCP SECRET************************'
echo ''
echo ''



#DCP MASTER
if [[ $enablelogstack == "true" ]]; then
    if kubectl get sts $releaselogstack -n $NAMESPACE &> /dev/null; then
        echo "=============================DCP LOG STACK already installed============================="
    else
        echo "===================================Create DCP LOG STACK=================================="
        sed -e "s#{{LOKI_REPOSITORY}}#$LOKI_REPOSITORY#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{LOKI_VERSION}}#$LOKI_VERSION#g;\
        s#{{LOKI_REQUEST_CPU}}#$LOKI_REQUEST_CPU#g;\
        s#{{LOKI_REQUEST_MEM}}#$LOKI_REQUEST_MEM#g;\
        s#{{LOKI_LIMIT_CPU}}#$LOKI_LIMIT_CPU#g;\
        s#{{LOKI_LIMIT_MEM}}#$LOKI_LIMIT_MEM#g;\
        s#{{LOKI_PERSISSTENCE_ENABLED}}#$LOKI_PERSISSTENCE_ENABLED#g;\
        s#{{LOKI_PERSISSTENCE_SIZE}}#$LOKI_PERSISSTENCE_SIZE#g;\
        s#{{LOKI_PERSISSTENCE_S3}}#$LOKI_PERSISSTENCE_S3#g;\
        s#{{PROMTAIL_REPOSITORY}}#$PROMTAIL_REPOSITORY#g;\
        s#{{PROMTAIL_VERSION}}#$PROMTAIL_VERSION#g;\
        s#{{PROMTAIL_DEPLOYMENT}}#$PROMTAIL_DEPLOYMENT#g;\
        s#{{PROMTAIL_DEPLOYMENT_REPLICAS}}#$PROMTAIL_DEPLOYMENT_REPLICAS#g;\
        s#{{PROMTAIL_REQUEST_CPU}}#$PROMTAIL_REQUEST_CPU#g;\
        s#{{PROMTAIL_REQUEST_MEM}}#$PROMTAIL_REQUEST_MEM#g;\
        s#{{PROMTAIL_LIMIT_CPU}}#$PROMTAIL_LIMIT_CPU#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PROMTAIL_DAEMON}}#$PROMTAIL_DAEMON#g;\
        s#{{PROMTAIL_LIMIT_MEM}}#$PROMTAIL_LIMIT_MEM#g;" $yamltemplate/log-stack-template.yaml > $yamldestination/log-stack.yaml

        
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaselogstack $repodir/loki-stack --values $yamldestination/log-stack.yaml
        fi
        echo 'DCP API created'
    fi
else
    echo '----------------DCP LOG STACK disabled--------------------'
fi


#DCP MASTER
if [[ $createdcpgrafana == "true" ]]; then
    if kubectl get sts $GRAFANA_NAME -n $NAMESPACE &> /dev/null; then
        echo "=============================DCP Grafana installed============================="
    else
        echo "===================================Create DCP Grafana=================================="
        sed -e "s#{{GRAFANA_NAME}}#$GRAFANA_NAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{NINXCLASS}}#$NINXCLASS#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
        s#{{GRAFANA_REPOSITORY}}#$GRAFANA_REPOSITORY#g;\
        s#{{GRAFANA_VERSION}}#$GRAFANA_VERSION#g;\
        s#{{GRAFANA_REQUEST_CPU}}#$GRAFANA_REQUEST_CPU#g;\
        s#{{GRAFANA_REQUEST_MEM}}#$GRAFANA_REQUEST_MEM#g;\
        s#{{GRAFANA_LIMIT_CPU}}#$GRAFANA_LIMIT_CPU#g;\
        s#{{GRAFANA_LIMIT_MEM}}#$GRAFANA_LIMIT_MEM#g;\
        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/grafana-template.yaml > $yamldestination/grafana.yaml

        echo "certificate: |" >> $yamldestination/grafana.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/grafana.yaml
        done
        echo "key: |-" >> $yamldestination/grafana.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/grafana.yaml
        done
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $GRAFANA_NAME $repodir/grafana --values $yamldestination/grafana.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo 'DCP API created'
    fi
else
    echo '----------------DCP API disabled--------------------'
fi



echo '************************START DCP STORAGE************************'
# create STORAGE
if [[ $enabledcpstorage == "true" ]]; then
    echo '----------------Create DCP STORAGE--------------------'
    sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
    s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
    s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
    s#{{KUBEVERSION}}#$KUBEVERSION#g;\
    s#{{PULLPOLICY}}#$PULLPOLICY#g;\
    s#{{SECRETNAME}}#$SECRETNAME#g;\
    s#{{NINXCLASS}}#$NINXCLASS#g;\
    
    s#{{RUNASUSER}}#$RUNASUSER#g;\
    s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\

    s#{{COMMONLABELS}}#$COMMONLABELS#g;\
    s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
    
    s#{{STORAGE_MODE}}#$STORAGE_MODE#g;\
    s#{{STORAGE_REPLICACOUNT}}#$STORAGE_REPLICACOUNT#g;\
    s#{{STORAGE_DRIVESPERNODE}}#$STORAGE_DRIVESPERNODE#g;\

    s#{{STORAGE_REPOSITORY}}#$STORAGE_REPOSITORY#g;\
    s#{{STORAGE_VERSION}}#$STORAGE_VERSION#g;\
    s#{{STORAGE_REPOSITORY_CLIENT}}#$STORAGE_REPOSITORY_CLIENT#g;\
    s#{{STORAGE_VERSION_CLIENT}}#$STORAGE_VERSION_CLIENT#g;\
    
    s#{{STORAGE_SSL_ENABLED}}#$STORAGE_SSL_ENABLED#g;\

    s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
    s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
    
    s#{{STORAGE_PERSISTNECE_ENABLED}}#$STORAGE_PERSISTNECE_ENABLED#g;\
    s#{{STORAGE_SIZE}}#$STORAGE_SIZE#g;\
    
    s#{{STORAGE_REQUESTCPU}}#$STORAGE_REQUESTCPU#g;\
    s#{{STORAGE_LIMITCPU}}#$STORAGE_LIMITCPU#g;\
    s#{{STORAGE_REQUESTMEMORY}}#$STORAGE_REQUESTMEMORY#g;\
    s#{{STORAGE_LIMITMEMORY}}#$STORAGE_LIMITMEMORY#g;\
    
    s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
    s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
    s#{{STORAGE_HOSTNAME}}#$STORAGE_HOSTNAME#g;" $yamltemplate/storage-template.yaml > $yamldestination/storage.yaml

    echo "certificate: |" >> $yamldestination/storage.yaml
    echo "$CERTIFICATE" | while IFS= read -r line; do
        echo "  $line" >> $yamldestination/storage.yaml
    done
    echo "key: |-" >> $yamldestination/storage.yaml
    echo "$KEYCERT" | while IFS= read -r line; do
        echo "  $line" >> $yamldestination/storage.yaml
    done

    if [[ $template == "false" ]]; then
        helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasestorage $repodir/minio --values $yamldestination/storage.yaml
    fi

    #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/dcp-storage-minio
    echo 'DCP storage created'
else
    echo 'DCP STORAGE NOT ENABLED'
fi
echo '************************END DCP STORAGE************************'
echo ''
echo ''

echo '************************START DCP DATABASE************************'
#DCP DATABASE
if [[ $createdatabase == "true" ]]; then
    if kubectl get sts $releasepgs-$dbarchitecture-postgresql -n $NAMESPACE &> /dev/null; then
        echo "=============================Databse already installed============================="
    else
        if [[ $dbarchitecture == "ha" ]]; then
            echo '****************************************Create DCP H.A. DATABASE****************************************'
            sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
            s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
            s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
            s#{{KUBEVERSION}}#$KUBEVERSION#g;\
            s#{{PULLPOLICY}}#$PULLPOLICY#g;\
            s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
            s#{{RUNASUSER}}#$RUNASUSER#g;\
            s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
            
            s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
            s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
            s#{{REDIS_SERVICENAME}}#$REDIS_SERVICENAME#g;\

            s#{{COMMONLABELS}}#$COMMONLABELS#g;\
            s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
            
            s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
            
            s#{{PGS_PERSISTENCE_ENABLED}}#$PGS_PERSISTENCE_ENABLED#g;\
            s#{{PGS_DATA_SIZE}}#$PGS_DATA_SIZE#g;\
            s#{{PGS_REPOSITORY}}#$PGS_REPOSITORY#g;\
            s#{{PGS_VERSION}}#$PGS_VERSION#g;\
            s#{{PGS_REPLICACOUNT}}#$PGS_REPLICACOUNT#g;\
            s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
            s#{{PGS_REQUEST_CPU}}#$PGS_REQUEST_CPU#g;\
            s#{{PGS_REQUEST_MEMORY}}#$PGS_REQUEST_MEMORY#g;\
            s#{{PGS_LIMIT_CPU}}#$PGS_LIMIT_CPU#g;\
            s#{{PGS_LIMIT_MEMORY}}#$PGS_LIMIT_MEMORY#g;\
            s#{{PGS_PDB_ENABLED}}#$PGS_PDB_ENABLED#g;\
            s#{{PGS_PDB_MINAVAILABLE}}#$PGS_PDB_MINAVAILABLE#g;\
            s#{{PGS_PDB_MAXUNAVAILABLE}}#$PGS_PDB_MAXUNAVAILABLE#g;\
            s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
            s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
            s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
            s#{{PGS_ROOTPASSWORD}}#$PGS_ROOTPASSWORD#g;\
            
            s#{{PGS_PGPOOL_REPOSITORY}}#$PGS_PGPOOL_REPOSITORY#g;\
            s#{{PGS_PGPOOL_VERSION}}#$PGS_PGPOOL_VERSION#g;\
            s#{{PGS_REPLICACOUNT}}#$PGS_REPLICACOUNT#g;\
            s#{{PGS_PGPOOL_REQUEST_CPU}}#$PGS_PGPOOL_REQUEST_CPU#g;\
            s#{{PGS_PGPOOL_REQUEST_MEMORY}}#$PGS_PGPOOL_REQUEST_MEMORY#g;\
            s#{{PGS_PGPOOL_LIMIT_CPU}}#$PGS_PGPOOL_LIMIT_CPU#g;\
            s#{{PGS_PGPOOL_LIMIT_MEMORY}}#$PGS_PGPOOL_LIMIT_MEMORY#g;\
            s#{{PGS_PGPOOL_PDB_ENABLED}}#$PGS_PGPOOL_PDB_ENABLED#g;\
            s#{{PGS_PGPOOL_PDB_MINAVAILABLE}}#$PGS_PGPOOL_PDB_MINAVAILABLE#g;\
            s#{{PGS_PGPOOL_PDB_MAXUNAVAILABLE}}#$PGS_PGPOOL_PDB_MAXUNAVAILABLE#g;\

            s#{{PGS_PGPOOL_NUMINITCHILDREN}}#$PGS_PGPOOL_NUMINITCHILDREN#g;\
            s#{{PGS_PGPOOL_RESERVEDCONNECTIONS}}#$PGS_PGPOOL_RESERVEDCONNECTIONS#g;\
            s#{{PGS_PGPOOL_MAXPOOL}}#$PGS_PGPOOL_MAXPOOL#g;\
            s#{{PGS_PGPOOL_CHILDMAXCONNECTIONS}}#$PGS_PGPOOL_CHILDMAXCONNECTIONS#g;\
            s#{{PGS_PGPOOL_CHILDLIFETIME}}#$PGS_PGPOOL_CHILDLIFETIME#g;\
            s#{{PGS_PGPOOL_CLIENTIDLELIMIT}}#$PGS_PGPOOL_CLIENTIDLELIMIT#g;\
            s#{{PGS_PGPOOL_CONNECTIONLIFETIME}}#$PGS_PGPOOL_CONNECTIONLIFETIME#g;\


            s#{{DIRVALUES}}#$DIRVALUES#g;\
            s#{{UPLOADDIRECTORY}}#$UPLOADDIRECTORY#g;\
            s#{{NAMESPACE}}#$NAMESPACE#g;\
            s#{{REDISPASWORD}}#$REDISPASWORD#g;\
            s#{{DCPSTORAGEACCESSKEY}}#$DCPSTORAGEACCESSKEY#g;\
            s#{{DCPSTORAGESECRETKEY}}#$DCPSTORAGESECRETKEY#g;\
            s#{{CREATESPARKHISTORYPATH}}#$CREATESPARKHISTORYPATH#g;\
            s#{{USERKEYCLOAKSERVICENAME}}#$USERKEYCLOAKSERVICENAME#g;\
            s#{{KUBEHOST}}#$KUBEHOST#g;\
            s#{{KUBEPORT}}#$KUBEPORT#g;\
            s#{{KUBEDNS}}#$KUBEDNS#g;\
            s#{{KUBELOG}}#$KUBELOG#g;\
            s#{{LDAP_URL}}#$LDAP_URL#g;\
            s#{{ROOTREPO}}#$ROOTREPO#g;" $yamltemplate/postgresql-ha-template.yaml > $yamldestination/postgresql-ha.yaml

            if [[ $template == "false" ]]; then
                helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasepgs $repodir/postgresql-ha --values $yamldestination/postgresql-ha.yaml
            fi

            echo '****************************************DCP database H.A created****************************************'
        elif [[ $dbarchitecture == "replication" ]]; then
            echo '----------------Create DCP REPLICATION DATABASE--------------------'
            sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
            s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
            s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
            s#{{KUBEVERSION}}#$KUBEVERSION#g;\
            s#{{PULLPOLICY}}#$PULLPOLICY#g;\
            s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
            s#{{RUNASUSER}}#$RUNASUSER#g;\
            s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\

            s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
            s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
            s#{{REDIS_SERVICENAME}}#$REDIS_SERVICENAME#g;\

            s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\

            s#{{COMMONLABELS}}#$COMMONLABELS#g;\
            s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
            
            s#{{PGS_ROOTPASSWORD}}#$PGS_ROOTPASSWORD#g;\
            s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
            s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
            s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
            
            s#{{PGS_REPLICATION_REPLICACOUNT}}#$PGS_REPLICATION_REPLICACOUNT#g;\
            s#{{PGS_REPLICATION_ARCHITECTURE}}#$PGS_REPLICATION_ARCHITECTURE#g;\
            
            s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
            s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
            
            s#{{PGS_REPLICATION_REQUESTCPU}}#$PGS_REPLICATION_REQUESTCPU#g;\
            s#{{PGS_REPLICATION_REQUESTMEMORY}}#$PGS_REPLICATION_REQUESTMEMORY#g;\
            s#{{PGS_REPLICATION_LIMITCPU}}#$PGS_REPLICATION_LIMITCPU#g;\
            s#{{PGS_REPLICATION_LIMITMEMORY}}#$PGS_REPLICATION_LIMITMEMORY#g;\

            s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
            s#{{PGS_PERSISTENCE_ENABLED}}#$PGS_PERSISTENCE_ENABLED#g;\
            s#{{PGS_DATA_SIZE}}#$PGS_DATA_SIZE#g;\

            s#{{DIRVALUES}}#$DIRVALUES#g;\
            s#{{UPLOADDIRECTORY}}#$UPLOADDIRECTORY#g;\
            s#{{NAMESPACE}}#$NAMESPACE#g;\
            s#{{REDISPASWORD}}#$REDISPASWORD#g;\
            s#{{DCPSTORAGEACCESSKEY}}#$DCPSTORAGEACCESSKEY#g;\
            s#{{DCPSTORAGESECRETKEY}}#$DCPSTORAGESECRETKEY#g;\
            s#{{CREATESPARKHISTORYPATH}}#$CREATESPARKHISTORYPATH#g;\
            s#{{USERKEYCLOAKSERVICENAME}}#$USERKEYCLOAKSERVICENAME#g;\
            s#{{KUBEHOST}}#$KUBEHOST#g;\
            s#{{KUBEPORT}}#$KUBEPORT#g;\
            s#{{KUBEDNS}}#$KUBEDNS#g;\
            s#{{KUBELOG}}#$KUBELOG#g;\
            s#{{LDAP_URL}}#$LDAP_URL#g;\
            s#{{ROOTREPO}}#$ROOTREPO#g;" $yamltemplate/postgresql-replication-template.yaml > $yamldestination/postgresql-replication.yaml

            if [[ $template == "false" ]]; then
                helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasepgs $repodir/postgresql --values $yamldestination/postgresql-replication.yaml
            fi

            echo 'DCP database REPLICATION created'
        fi
    fi
else
    echo '----------------DCP DATABASE IGNORED--------------------'
fi
echo '************************END DCP DATABASE************************'
echo ''
echo ''

echo '************************START INIT DCP DATABASE************************'
#INIT DATABASE
if [[ $initdatabase == "true" ]]; then
    echo '----------------INIT DATABASE---------------------'
    sed -e "s#{{DIRVALUES}}#$DIRVALUES#g;\
    s#{{UPLOADDIRECTORY}}#$UPLOADDIRECTORY#g;\
    s#{{NAMESPACE}}#$NAMESPACE#g;\
    s#{{REGISTRY}}#$REGISTRY#g;\
    s#{{REPOSITORY}}#$REPOSITORY#g;\
    s#{{DEFAULT_CLOUD_NAME}}#$DEFAULT_CLOUD_NAME#g;\
    s#{{REDISPASWORD}}#$REDISPASWORD#g;\
    s#{{DCPSTORAGEACCESSKEY}}#$DCPSTORAGEACCESSKEY#g;\
    s#{{DCPSTORAGESECRETKEY}}#$DCPSTORAGESECRETKEY#g;\
    s#{{CREATESPARKHISTORYPATH}}#$CREATESPARKHISTORYPATH#g;\
    s#{{USERKEYCLOAKSERVICENAME}}#$USERKEYCLOAKSERVICENAME#g;\
    s#{{NINXCLASS}}#$NINXCLASS#g;\
    s#{{SECRETNAME}}#$SECRETNAME#g;\
    s#{{PULLPOLICY}}#$PULLPOLICY#g;\
    s#{{DOMAIN}}#$DOMAIN#g;\
    s#{{USEINGRESSCLASSNAME}}#$USEINGRESSCLASSNAME#g;\
    s#{{KUBEHOST}}#$KUBEHOST#g;\
    s#{{KUBEPORT}}#$KUBEPORT#g;\
    s#{{KUBEDNS}}#$KUBEDNS#g;\
    s#{{KUBELOG}}#$KUBELOG#g;\
    s#{{LDAP_URL}}#$LDAP_URL#g;\
    s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
    s#{{GRAFANA_NAME}}#$GRAFANA_NAME#g;\
    s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
    s#{{REDIS_SERVICENAME}}#$REDIS_SERVICENAME#g;\
    s#{{STORAGE_ACCESSKEY}}#$STORAGE_ACCESSKEY#g;\
    s#{{STORAGE_SECRETKEY}}#$STORAGE_SECRETKEY#g;\
    s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
    s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
    s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
    s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
    s#{{ROOTREPO}}#$ROOTREPO#g;" $yamltemplate/insert-Configmap-template.yaml > $yamldestination/insert-Configmap.yaml
    
    
    sed -e "s#{{REGISTRY}}#$REGISTRY#g;\
    s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
    s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
    s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
    s#{{NAMESPACE}}#$NAMESPACE#g;\
    s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
    s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
    s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
    s#{{RUNASUSER}}#$RUNASUSER#g;\
    s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
    s#{{PULLPOLICY}}#$PULLPOLICY#g;\
    s#{{COMMONLABELSHEIGHT}}#$COMMONLABELSHEIGHT#g;\
    s#{{PGS_DATABASE}}#$PGS_DATABASE#g;" $yamltemplate/insert-Job-template.yaml > $yamldestination/insert-Job.yaml

    if [[ $template == "false" ]]; then
        kubectl -n $NAMESPACE apply -f $yamldestination/insert-Configmap.yaml
        sleep 3
        kubectl -n $NAMESPACE delete -f $yamldestination/insert-Job.yaml
        sleep 3
        kubectl -n $NAMESPACE apply -f $yamldestination/insert-Job.yaml
    fi
else
    echo '----------------INIT DATABASE IGNORED--------------------'
fi
echo '************************END INIT DCP DATABASE************************'
echo ''
echo ''
#sleep 10

#DCP MASTER
if [[ $createdcpapi == "true" ]]; then
    if kubectl get sts $releasemaster -n $NAMESPACE &> /dev/null; then
        echo "=============================DCP API already installed============================="
    else
        echo "===================================Create DCP API=================================="
        sed -e "s#{{MASTER_NAME}}#$MASTER_NAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{NINXCLASS}}#$NINXCLASS#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{MASTER_REPLICACOUNT}}#$MASTER_REPLICACOUNT#g;\
        s#{{MASTER_ALLINONEPOD}}#$MASTER_ALLINONEPOD#g;\
        s#{{MASTER_API_VERSION}}#$MASTER_API_VERSION#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        
        s#{{MASTER_HOSTALIASES}}#$MASTER_HOSTALIASES#g;\
        s#{{MASTER_DNSCONFIG}}#$MASTER_DNSCONFIG#g;\

        s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\

        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{MASTER_REPOSITORY}}#$MASTER_REPOSITORY#g;\
        s#{{MASTER_VERSION}}#$MASTER_VERSION#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\

        s#{{MASTER_ENABLE_AUTOSCALING}}#$MASTER_ENABLE_AUTOSCALING#g;\
        s#{{MASTER_MINREPLICAS}}#$MASTER_MINREPLICAS#g;\
        s#{{MASTER_MAXREPLICAS}}#$MASTER_MAXREPLICAS#g;\
        s#{{MASTER_TARGETCPU}}#$MASTER_TARGETCPU#g;\
        s#{{MASTER_TARGETMEMORY}}#$MASTER_TARGETMEMORY#g;\

        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{MASTER_SERVICE_ACCOUNT}}#$MASTER_SERVICE_ACCOUNT#g;\
        s#{{MASTER_CLUSTER_ROLE}}#$MASTER_CLUSTER_ROLE#g;\
        s#{{MASTER_NAMESPACES}}#$MASTER_NAMESPACES#g;\

        s#{{MASTER_SSL_ENABLED}}#$MASTER_SSL_ENABLED#g;\
        s#{{MASTER_SSL_AUTOGENERATED}}#$MASTER_SSL_AUTOGENERATED#g;\
        s#{{INIT_IMAGE}}#$INIT_IMAGE#g;\
        s#{{MASTER_KEYSTORE_PATH}}#$MASTER_KEYSTORE_PATH#g;\
        s#{{MASTER_KEYSTORE_PASSWORD}}#$MASTER_KEYSTORE_PASSWORD#g;\
        s#{{MASTER_TRUSTSTORE_PATH}}#$MASTER_TRUSTSTORE_PATH#g;\
        s#{{MASTER_INIT_REQUESTCPU}}#$MASTER_INIT_REQUESTCPU#g;\
        s#{{MASTER_INIT_REQUESTMEMORY}}#$MASTER_INIT_REQUESTMEMORY#g;\
        s#{{MASTER_INIT_LIMITCPU}}#$MASTER_INIT_LIMITCPU#g;\
        s#{{MASTER_INIT_LIMITMEMORY}}#$MASTER_INIT_LIMITMEMORY#g;\

        s#{{MASTER_PGS_CONNECTION_TIMEOUT}}#$MASTER_PGS_CONNECTION_TIMEOUT#g;\
        s#{{MASTER_PGS_MAXIMUMPOOLSIZE}}#$MASTER_PGS_MAXIMUMPOOLSIZE#g;\

        s#{{LDAP_SECURED}}#$LDAP_SECURED#g;\
        s#{{LDAP_FACTORY}}#$LDAP_FACTORY#g;\
        s#{{LDAP_URL}}#$LDAP_URL#g;\
        s#{{LDAP_PRINCIPAL}}#$LDAP_PRINCIPAL#g;\
        s#{{LDAP_GIVENNAME}}#$LDAP_GIVENNAME#g;\
        s#{{LDAP_SHORTNAME}}#$LDAP_SHORTNAME#g;\
        s#{{LDAP_EMAIL}}#$LDAP_EMAIL#g;\
        s#{{LDAP_GROUP}}#$LDAP_GROUP#g;\
        s#{{LDAP_UID}}#$LDAP_UID#g;\
        s#{{LDAP_VIEWALLATTRIBUTES}}#$LDAP_VIEWALLATTRIBUTES#g;\
        s#{{LDAP_FILTERSEARCH}}#$LDAP_FILTERSEARCH#g;\

        s#{{LDAP_SEARCHMETHOD}}#$LDAP_SEARCHMETHOD#g;\
        s#{{LDAP_CANGETATTRIBUTE}}#$LDAP_CANGETATTRIBUTE#g;\
        s#{{LDAP_SCOPELEVEL}}#$LDAP_SCOPELEVEL#g;\
        s#{{LDAP_AUTHENTICATIONTYPE}}#$LDAP_AUTHENTICATIONTYPE#g;\
        s#{{LDAP_BINDDN}}#$LDAP_BINDDN#g;\
        s#{{LDAP_BINDPASSWORD}}#$LDAP_BINDPASSWORD#g;\
        s#{{LDAP_ATTRIBUTES}}#$LDAP_ATTRIBUTES#g;\
        s#{{LDAP_BINDFILTERSEARCH}}#$LDAP_BINDFILTERSEARCH#g;\

        s#{{MASTER_EXTRAS_FILES}}#$MASTER_EXTRAS_FILES#g;\
        s#{{MASTER_EXTRAS_HOSTNAMES}}#$MASTER_EXTRAS_HOSTNAMES#g;\

        s#{{MASTER_REQUESTCPU}}#$MASTER_REQUESTCPU#g;\
        s#{{MASTER_REQUESTMEMORY}}#$MASTER_REQUESTMEMORY#g;\
        s#{{MASTER_LIMITCPU}}#$MASTER_LIMITCPU#g;\
        s#{{MASTER_LIMITMEMORY}}#$MASTER_LIMITMEMORY#g;\

        s#{{MASTER_PERSISTENCE_ENABLED}}#$MASTER_PERSISTENCE_ENABLED#g;\
        s#{{MASTER_PERSISTENCE_SIZE}}#$MASTER_PERSISTENCE_SIZE#g;\

        s#{{LOGWATCHER_REQUESTCPU}}#$LOGWATCHER_REQUESTCPU#g;\
        s#{{LOGWATCHER_REQUESTMEMORY}}#$LOGWATCHER_REQUESTMEMORY#g;\
        s#{{LOGWATCHER_LIMITCPU}}#$LOGWATCHER_LIMITCPU#g;\
        s#{{LOGWATCHER_LIMITMEMORY}}#$LOGWATCHER_LIMITMEMORY#g;\
        
        s#{{LOGWATCHER_SERVICENAME}}#$LOGWATCHER_SERVICENAME#g;\

        s#{{MASTER_CLUSTER_ROLE}}#$MASTER_CLUSTER_ROLE#g;\
        
        s#{{PODWATCHER_CLEANPODS}}#$PODWATCHER_CLEANPODS#g;\
        s#{{PODWATCHER_REQUESTCPU}}#$PODWATCHER_REQUESTCPU#g;\
        s#{{PODWATCHER_REQUESTMEMORY}}#$PODWATCHER_REQUESTMEMORY#g;\
        s#{{PODWATCHER_LIMITCPU}}#$PODWATCHER_LIMITCPU#g;\
        s#{{PODWATCHER_LIMITMEMORY}}#$PODWATCHER_LIMITMEMORY#g;\
        
        s#{{PODWATCHER_NAMESPACES}}#$PODWATCHER_NAMESPACES#g;\

        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
        
        s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
        s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
        s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
        s#{{PGS_REPLICATION_ARCHITECTURE}}#$PGS_REPLICATION_ARCHITECTURE#g;\
        s#{{PGS_REPLICACOUNT}}#$PGS_REPLICACOUNT#g;\
        s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
        s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
        
        s#{{HEALTH_HEARTBEAT}}#$HEALTH_HEARTBEAT#g;\
        s#{{HEALTH_DELAY}}#$HEALTH_DELAY#g;\
        s#{{HEALTH_REQUESTCPU}}#$HEALTH_REQUESTCPU#g;\
        s#{{HEALTH_REQUESTMEMORY}}#$HEALTH_REQUESTMEMORY#g;\
        s#{{HEALTH_LIMITCPU}}#$HEALTH_LIMITCPU#g;\
        s#{{HEALTH_LIMITMEMORY}}#$HEALTH_LIMITMEMORY#g;\
        s#{{MASTER_LOGLEVEL}}#$MASTER_LOGLEVEL#g;\

        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/master-template-copy.yaml > $yamldestination/master.yaml

        echo "certificate: |" >> $yamldestination/master.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/master.yaml
        done
        echo "key: |-" >> $yamldestination/master.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/master.yaml
        done
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemaster $repodir/master-api-old --values $yamldestination/master.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo 'DCP API created'
    fi
else
    echo '----------------DCP API disabled--------------------'
fi

#DCP PROXY
if [[ $enabledcpproxy == "true" ]]; then
    if kubectl get sts $releasemasterproxy -n $NAMESPACE &> /dev/null; then
        echo "=============================DCP PROXY already installed============================="
    else
        echo '----------------Create DCP PROXY--------------------'
        sed -e "s#{{PROXYNAME}}#$PROXYNAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{NINXCLASS}}#$NINXCLASS#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PROXYSCHEDULERNAME}}#$PROXYSCHEDULERNAME#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        
        s#{{CERT_MANAGER_DNSNAMES}}#$CERT_MANAGER_DNSNAMES#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\

        s#{{PROXYREPLICACOUNT}}#$PROXYREPLICACOUNT#g;\
        s#{{PROXYSERVICEACCOUNT}}#$PROXYSERVICEACCOUNT#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\

        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{PROXY_REPOSITORY}}#$PROXY_REPOSITORY#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{PROXY_VERSION}}#$PROXY_VERSION#g;\
        
        s#{{PROXYREQUESTCPU}}#$PROXYREQUESTCPU#g;\
        s#{{PROXYREQUESTMEMORY}}#$PROXYREQUESTMEMORY#g;\
        s#{{PROXYLIMITCPU}}#$PROXYLIMITCPU#g;\
        s#{{PROXYLIMITMEMORY}}#$PROXYLIMITMEMORY#g;\
        
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
        
        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/proxy-template.yaml > $yamldestination/proxy.yaml

        echo "certificate: |" >> $yamldestination/proxy.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/proxy.yaml
        done
        echo "key: |-" >> $yamldestination/proxy.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/proxy.yaml
        done

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemasterproxy $repodir/master-proxy-appli --values $yamldestination/proxy.yaml
        fi

        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy

        echo '----------------DCP PROXY created--------------------'
    fi
else
    echo '----------------DCP Proxy disabled--------------------'
fi

#DCP SCHEDULER
if [[ $createdcpscheduler == "true" ]]; then
    if kubectl get deploy $releasescheduler -n $NAMESPACE &> /dev/null; then
        echo "=============================DCP SCHEDULER already installed============================="
    else
        echo '----------------Create DCP SCHEDULER--------------------'
        sed -e "s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{releasescheduler}}#$releasescheduler#g;\
        
        
        s#{{ADMISSION_REPOSITORY}}#$ADMISSION_REPOSITORY#g;\
        s#{{ADMISSION_VERSION}}#$ADMISSION_VERSION#g;\
        s#{{ADMISSION_REQUESTCPU}}#$ADMISSION_REQUESTCPU#g;\
        s#{{ADMISSION_LIMITCPU}}#$ADMISSION_LIMITCPU#g;\
        s#{{ADMISSION_REQUESTMEMORY}}#$ADMISSION_REQUESTMEMORY#g;\
        s#{{ADMISSION_LIMITMEMORY}}#$ADMISSION_LIMITMEMORY#g;\
        
        s#{{PLUGIN_REPOSITORY}}#$PLUGIN_REPOSITORY#g;\
        s#{{PLUGIN_VERSION}}#$PLUGIN_VERSION#g;\

        s#{{WEB_REPOSITORY}}#$WEB_REPOSITORY#g;\
        s#{{WEB_VERSION}}#$WEB_VERSION#g;\
        s#{{WEB_REQUESTCPU}}#$WEB_REQUESTCPU#g;\
        s#{{WEB_LIMITCPU}}#$WEB_LIMITCPU#g;\
        s#{{WEB_REQUESTMEMORY}}#$WEB_REQUESTMEMORY#g;\
        s#{{WEB_LIMITMEMORY}}#$WEB_LIMITMEMORY#g;\
        
        s#{{SCHEDULER_REPOSITORY}}#$SCHEDULER_REPOSITORY#g;\
        s#{{SCHEDULER_VERSION}}#$SCHEDULER_VERSION#g;\
        s#{{SCHEDULER_REQUESTCPU}}#$SCHEDULER_REQUESTCPU#g;\
        s#{{SCHEDULER_LIMITCPU}}#$SCHEDULER_LIMITCPU#g;\
        s#{{SCHEDULER_REQUESTMEMORY}}#$SCHEDULER_REQUESTMEMORY#g;\
        s#{{SCHEDULER_LIMITMEMORY}}#$SCHEDULER_LIMITMEMORY#g;\
        s#{{SCHEDULER_ENABLEOSROOT}}#$SCHEDULER_ENABLEOSROOT#g;\
        s#{{SCHEDULER_ENABLEINGRESS}}#$SCHEDULER_ENABLEINGRESS#g;\
        s#{{SCHEDULER_INGRESSHOSTNAME}}#$SCHEDULER_INGRESSHOSTNAME#g" $yamltemplate/scheduler-template.yaml > $yamldestination/scheduler.yaml
        
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasescheduler $repodir/scheduler --values $yamldestination/scheduler.yaml
        fi
    fi
else
    echo '----------------DCP SCHEDULER NOT ENABLED--------------------'
fi

#DCP REDIS
if [[ $enabledcpredis == "true" ]]; then
    #if kubectl get sts dcp-pgs-$dbarchitecture-postgresql -n $NAMESPACE &> /dev/null; then
    #    echo "=============================REDIS already installed============================="
    #else
    if [[ $redisarchitecture == "replication" ]]; then
        echo '----------------Create DCP REDIS REPLICATION--------------------'
        sed -e "s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{REDISPASWORD}}#$REDISPASWORD#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\

        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{REDIS_REPLICATION_REPOSITORY}}#$REDIS_REPLICATION_REPOSITORY#g;\
        s#{{REDIS_REPLICATION_VERSION}}#$REDIS_REPLICATION_VERSION#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\

        s#{{REDIS_REPLICATION_ARCHITECTURE}}#$REDIS_REPLICATION_ARCHITECTURE#g;\

        s#{{REDIS_REPLICATION_REQUESTCPU_MASTER}}#$REDIS_REPLICATION_REQUESTCPU_MASTER#g;\
        s#{{REDIS_REPLICATION_REQUESTMEMORY_MASTER}}#$REDIS_REPLICATION_REQUESTMEMORY_MASTER#g;\
        s#{{REDIS_REPLICATION_LIMITCPU_MASTER}}#$REDIS_REPLICATION_LIMITCPU_MASTER#g;\
        s#{{REDIS_REPLICATION_LIMITMEMORY_MASTER}}#$REDIS_REPLICATION_LIMITMEMORY_MASTER#g;\
        s#{{REDIS_REPLICATION_DATASIZE_MASTER}}#$REDIS_REPLICATION_DATASIZE_MASTER#g;\

        s#{{REDIS_REPLICATION_USER}}#$REDIS_REPLICATION_USER#g;\
        
        s#{{REDIS_REPLICATION_REQUESTCPU_WORKER}}#$REDIS_REPLICATION_REQUESTCPU_WORKER#g;\
        s#{{REDIS_REPLICATION_REQUESTMEMORY_WORKER}}#$REDISUREDIS_REPLICATION_REQUESTMEMORY_WORKERSER#g;\
        s#{{REDIS_REPLICATION_LIMITCPU_WORKER}}#$REDIS_REPLICATION_LIMITCPU_WORKER#g;\
        s#{{REDIS_REPLICATION_LIMITMEMORY_WORKER}}#$REDIS_REPLICATION_LIMITMEMORY_WORKER#g;\
        s#{{REDIS_REPLICATION_DATASIZE_WORKER}}#$REDIS_REPLICATION_DATASIZE_WORKER#g;\

        s#{{REDISREPLICATION_ENABLE_AUTOSCALING}}#$REDISREPLICATION_ENABLE_AUTOSCALING#g;\
        s#{{REDISREPLICATION_ENABLE_MINREPLICAS}}#$REDISREPLICATION_ENABLE_MINREPLICAS#g;\
        s#{{REDISREPLICATION_ENABLE_MAXREPLICAS}}#$REDISREPLICATION_ENABLE_MAXREPLICAS#g;\
        s#{{REDISREPLICATION_ENABLE_TARGETCPU}}#$REDISREPLICATION_ENABLE_TARGETCPU#g;\
        s#{{REDISREPLICATION_ENABLE_TARGETMEMORY}}#$REDISREPLICATION_ENABLE_TARGETMEMORY#g;\

        s#{{REDIS_REPLICATION_REPLICACOUNT_WORKER}}#$REDIS_REPLICATION_REPLICACOUNT_WORKER#g;\
        s#{{REDIS_REPLICATION_SCHEDULERNAME}}#$REDIS_REPLICATION_SCHEDULERNAME#g;" $yamltemplate/redis-template.yaml > $yamldestination/dcp-redis.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaseredis $repodir/redis --values $yamldestination/dcp-redis.yaml
        fi
        
        echo 'DCP REDIS REPLICATION created'
    
    elif [[ $redisarchitecture == "cluster" ]]; then

        echo '----------------Create DCP REDIS CLUSTER--------------------'
        sed -e "s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{REDISPASWORD}}#$REDISPASWORD#g;\
        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{RUNASUSER}}#$RUNASUSER#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\

        s#{{REDIS_CLUSTER_REPOSITORY}}#$REDIS_CLUSTER_REPOSITORY#g;\
        s#{{REDIS_CLUSTER_VERSION}}#$REDIS_CLUSTER_VERSION#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{REDIS_CLUSTER_USER}}#$REDIS_CLUSTER_USER#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{REDIS_CLUSTER_REQUESTCPU}}#$REDIS_CLUSTER_REQUESTCPU#g;\
        s#{{REDIS_CLUSTER_REQUESTMEMORY}}#$REDIS_CLUSTER_REQUESTMEMORY#g;\
        s#{{REDIS_CLUSTER_LIMITCPU}}#$REDIS_CLUSTER_LIMITCPU#g;\
        s#{{REDIS_CLUSTER_LIMITMEMORY}}#$REDIS_CLUSTER_REQUESTMEMORY#g;\
        s#{{REDIS_CLUSTER_DATASIZE}}#$REDIS_CLUSTER_DATASIZE#g;\
        s#{{REDIS_CLUSTER_NODES}}#$REDIS_CLUSTER_NODES#g;\
        s#{{REDIS_CLUSTER_REPLICAS}}#$REDIS_CLUSTER_REPLICAS#g;\
        s#{{REDIS_CLUSTER_SCHEDULERNAME}}#$REDIS_CLUSTER_SCHEDULERNAME#g;" $yamltemplate/redis-cluster-template.yaml > $yamldestination/redis-cluster.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaseredis $repodir/redis-cluster --values $yamldestination/redis-cluster.yaml
        fi
        
        echo 'DCP REDIS CLUSTER created'
    fi
    #fi
else
    echo '----------------DCP REDIS REPLICATION IGNORED--------------------'
fi