#!/bin/bash

# Load environnement varaibles
. ./env.sh

#GLOBAL
NAMESPACE=dcpsoftware
repodir=$(pwd)/repos
yamltemplate=$(pwd)/templates
yamldestination=$(pwd)/yamls

releasepgs="masterdb"
releasemaster="masterapi"
releasemasterproxy=masterproxy
SECRETNAME=mastersecret
releasescheduler=masterscheduler
releasestorage=masterstorage
releaseredis="masterredis"

releaselogstack="loki"
GRAFANA_NAME="dcpgrafana"

echo '----------------Delete DCP MemCache--------------------'
helm -n $NAMESPACE uninstall $releaseredis
kubectl -n $NAMESPACE delete pvc --selector=app.kubernetes.io/instance=$releaseredis --wait=false

echo '----------------Delete DCP Proxy--------------------'
helm -n $NAMESPACE uninstall $releasemasterproxy

echo '----------------Delete DCP Scheduler--------------------'
helm -n $NAMESPACE uninstall $releasescheduler
kubectl -n $NAMESPACE delete cm $releasescheduler-defaults
kubectl -n $NAMESPACE delete cm yunikorn-defaults
kubectl -n $NAMESPACE delete rolebinding releasescheduler-rbac
kubectl -n $NAMESPACE delete role $releasescheduler
kubectl -n $NAMESPACE delete sa dcpscheduler-admission-controller
kubectl -n $NAMESPACE delete sa $releasescheduler-admin


echo '----------------Delete DCP API--------------------'
helm -n $NAMESPACE uninstall $releasemaster
kubectl -n $NAMESPACE delete pvc --selector=app.kubernetes.io/instance=$releasemaster --wait=false

echo '----------------Delete DCP Databse--------------------'
helm -n $NAMESPACE uninstall $releasepgs
kubectl -n $NAMESPACE delete pvc --selector=app.kubernetes.io/instance=$releasepgs --wait=false

echo '----------------Delete DCP Storage--------------------'
helm -n $NAMESPACE uninstall $releasestorage

echo '----------------Delete DCP Secret--------------------'
helm -n $NAMESPACE uninstall $SECRETNAME

echo '----------------Delete DCP Log Stach--------------------'
helm -n $NAMESPACE uninstall $releaselogstack
kubectl -n $NAMESPACE delete pvc --selector=release=$releaselogstack --wait=false

echo '----------------Delete DCP Grafana--------------------'
helm -n $NAMESPACE uninstall $GRAFANA_NAME

kubectl -n $NAMESPACE delete -f $yamldestination/insert-Configmap.yaml
kubectl -n $NAMESPACE delete -f $yamldestination/insert-Job.yaml
kubectl -n $NAMESPACE delete job postgresql-job